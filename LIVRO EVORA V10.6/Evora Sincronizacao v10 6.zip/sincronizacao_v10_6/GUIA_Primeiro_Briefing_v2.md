# Guia — Primeiro Briefing Real do Évora (v2 · alinhado ao Manual v10.6)

Este guia leva você do zero ao primeiro briefing real da Tatiane. Siga na ordem.

> **v2 · 18/07/2026 — o que mudou:** removido o passo `pip install` (o motor usa só a biblioteca padrão do Python — não há nada a instalar); instruções de chave agora em **Windows (PowerShell)** e **Mac/Linux** lado a lado; motor referenciado é o **v2** (dirigido pelo perfil do tenant, limiar 25% lido do perfil).

## Parte 0 — Tenant novo? Comece pela Entrevista de Fundação `[v10.6]`

Se você está implantando para **um cliente novo** (não a Tatiane), rode primeiro:

```powershell
python entrevista_fundacao.py
```

São 14 perguntas, cerca de 8 minutos. No fim, o script gera o `perfil_<tenant>.json`
que o motor lê — sem edição manual — e lista na tela o que ainda falta antes do go-live.

Duas coisas que o script **não deixa passar**:
- Sem a ciência das 3 travas, o perfil sai marcado `operacional: false` e o go-live fica bloqueado.
- Os veículos saem vazios de propósito: a verificação humana da mídia local é obrigatória
  antes do go-live (o Atlas preenche o rascunho, mas alguém confere).

Para a Tatiane (tenant zero), pule esta parte — o perfil dela já existe.

## Parte 1 — Conseguir a chave da API (uma vez só)

1. Acesse **console.anthropic.com** e faça login (é a conta de desenvolvedor, separada do app Claude).
2. Verifique o telefone por SMS (pode liberar ~US$5 de crédito de teste).
3. **Settings → Billing:** adicione um cartão, ponha um crédito pequeno (US$5) e um limite mensal (ex.: US$10). *Sem billing, a chave existe mas as chamadas falham.*
4. **API Keys → Create Key:** dê o nome **Evora-Briefing** e crie.
5. **Copie a chave imediatamente** (aparece uma vez só; começa com `sk-ant-`). Guarde em lugar seguro.

## Parte 2 — Preparar a máquina (uma vez só)

Só é preciso ter o **Python 3.10 ou superior**. Não há nada para instalar — o motor usa somente a biblioteca padrão.

**Windows (PowerShell):**
```powershell
python --version    # deve mostrar 3.10 ou superior
```

**Mac/Linux:**
```bash
python3 --version
```

Se o Python não estiver instalado no Windows, baixe em **python.org/downloads** e, na instalação, marque **"Add Python to PATH"**.

## Parte 3 — Rodar o briefing

**Windows (PowerShell):**
```powershell
cd caminho\para\motor

# 1) colar a chave (vale NESTA janela do PowerShell; troque pela sua)
$env:ANTHROPIC_API_KEY = "sk-ant-XXXXXXXX"

# 2) rodar o orquestrador (coleta + Bia escreve + renderiza)
python orquestrador_evora.py
```

> ⚠️ **Pegadinha do Windows:** o comando `setx` NÃO funciona para a janela atual (só vale para janelas novas). Use sempre `$env:` como acima. Se fechar o PowerShell, cole a chave de novo.

**Mac/Linux:**
```bash
cd caminho/para/motor
export ANTHROPIC_API_KEY="sk-ant-XXXXXXXX"
python3 orquestrador_evora.py
```

**3)** O briefing sai em `briefing_AAAAMMDD.html` na pasta do motor (e uma cópia na pasta **Evora Fable** da Área de Trabalho, quando localizável). Abra no navegador.

## O que este motor (v2) já traz

- **Dirigido pelo perfil do tenant:** identidade, tom, blocos, limiar e consultas vêm de `perfil_tatiane.json`. Trocar de cliente = trocar o perfil, sem tocar no código.
- **Perfil da Tatiane:** temas reais (cultura, educação, segurança, proteção à mulher, misoginia), variações do nome.
- **5 jornais de Sorocaba:** Cruzeiro do Sul, Z Norte (Sorocabanices), Jornal Ipanema, Giro Sorocaba, Portal Porque — consultas geradas do perfil.
- **Diário Oficial** via COM (noticias.sorocaba.sp.gov.br/jornal) — conector em construção; até lá o bloco sai "Sem dado hoje."
- **Fiscalização** com limiar de **25% lido do perfil** (ajustável no perfil; mudança registrada).
- **Os 7 blocos canônicos:** Resumo · Radar de Nomeações · Fiscalização · Pulso da Câmara/DO · Demandas · Monitoramento & Imprensa · Movimento sugerido (72h). Bloco sem dado sai como **"Sem dado hoje."**
- **Caráter travado:** sem invenção, fonte declarada (CVI), "não sei" é válido, freio humano.
- **Honestidade de resultado:** o orquestrador só declara "Briefing gerado" se o arquivo de fato existir; falhas vão para `avisos_evora.log`.

## Se der erro

- **401 (não autorizado):** chave errada ou com espaço extra ao colar. Refaça o `$env:` (Windows) ou o `export` (Mac/Linux).
- **402 / billing:** falta cartão/crédito no console. Volte à Parte 1, passo 3.
- **Sem conexão:** o montador avisa com mensagem clara (sem traceback). Verifique a internet e rode de novo.
- **Sem resultado de alguma fonte:** o motor degrada avisando e segue com as demais (não trava). Veja `avisos_evora.log`.

## Ordem honesta de expectativa

No primeiro briefing, a coleta de alguns jornais pode vir parcial (sites variam). A imprensa via agregador vem de primeira; PNCP depende do endpoint confirmado; Diário Oficial e Demandas entram nas fases seguintes. Isso é o esperado — e o briefing diz "Sem dado hoje." onde faltar, em vez de inventar.

---

*v2 · 18/07/2026 · substitui o guia "atualizado v9.9" · Confidencial — Eng. Luiz Gonzaga Filho*
