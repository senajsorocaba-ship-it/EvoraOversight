# ROTEIRO DO LAPTOP — APOSENTADO (18/07/2026)

Este documento substitui o `ROTEIRO_LAPTOP_v3.md`, aposentado por decisão do fundador em 18/07/2026.

**Motivos do registro (Anexo 14 do Manual v10.6):** o cabeçalho dizia "v2" num arquivo v3, e o texto declarava como "aplicadas e validadas" correções que não estavam nos arquivos da pasta do projeto (dessincronização detectada e corrigida em 18/07).

**O que assume o papel dele:**
- Mapa da sessão de instalação e execução → `INSTRUCOES_CODAR_BRIEFING_v2.md`
- Passo a passo humano do primeiro briefing → `GUIA_Primeiro_Briefing_v2.md`
- Estado real e regras de sincronização → Manual v10.6, Anexo 14

O arquivo original não deve ser apagado (regra de ouro: nada se apaga) — apenas movido para a pasta `arquivo_historico/` com este aviso ao lado.
