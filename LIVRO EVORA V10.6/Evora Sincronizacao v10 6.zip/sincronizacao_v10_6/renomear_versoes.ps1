# Évora — Higiene de Versões (item 7 · 18/07/2026)
# Regra do Manual v10.5 (Anexo 14): nunca dois arquivos com o mesmo número
# de versão e conteúdos diferentes. Este script carimba data/hora de
# modificação no nome das duplicatas conhecidas e move originais
# substituídos para arquivo_historico\ . NADA é apagado.
# USO: abra o PowerShell NA PASTA onde estão os arquivos e rode:
#   powershell -ExecutionPolicy Bypass -File .\renomear_versoes.ps1

$historico = "arquivo_historico"
New-Item -ItemType Directory -Force -Path $historico | Out-Null

$alvos = @(
  "Evora Manual v10_3.md",
  "Evora Manual v10_4.md",
  "Evora_Manual_v10_5.md",
  "ROTEIRO_LAPTOP_v3.md",
  "ROTEIRO LAPTOP v1.md"
)

Get-ChildItem -File | Where-Object {
    $n = $_.Name -replace '^\d+-',''   # ignora prefixo numérico do WhatsApp
    $alvos -contains $n
} | ForEach-Object {
    $carimbo = $_.LastWriteTime.ToString("yyyyMMdd_HHmm")
    $novo = "{0}__{1}{2}" -f $_.BaseName, $carimbo, $_.Extension
    Move-Item $_.FullName (Join-Path $historico $novo)
    Write-Host ("arquivado: {0}  ->  {1}\{2}" -f $_.Name, $historico, $novo)
}

Write-Host ""
Write-Host "Concluido. Fonte unica da verdade a partir de agora:"
Write-Host "  Manual  -> Evora_Manual_v10_6.md"
Write-Host "  Pipeline-> Briefing_Matinal_Pipeline_v1_1.md"
Write-Host "  Guia    -> GUIA_Primeiro_Briefing_v2.md"
Write-Host "  Motor   -> pasta motor\ (v2, dirigido pelo perfil)"
