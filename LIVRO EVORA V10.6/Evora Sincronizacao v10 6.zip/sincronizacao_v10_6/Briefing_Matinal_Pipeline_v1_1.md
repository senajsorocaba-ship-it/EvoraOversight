# Briefing Matinal — Espec do Pipeline (v1.1)

**Produto:** Briefing Político Matinal (MVP do Évora Oversight)
**Cliente-piloto:** Vereadora Tatiane Costa (PL) — pré-campanha Deputada Federal 2026, Sorocaba/SP
**Entrega:** todo dia às **06:45**, modo **sigiloso** (operado pelas assessoras; a autoridade recebe como produção da equipe)
**Orquestrador:** Bia-g (Gestora de Gabinete)

> **v1.1 · 18/07/2026 — o que mudou.** (1) Sigla corrigida em todo o documento: **AFGm-g → AFEx-g** (nome travado desde a v7.1 do Manual; ratificado pelo fundador em 18/07). (2) Saída-alvo alinhada aos **7 blocos canônicos do perfil do tenant** (Manual v10.6), substituindo os 6 blocos do demo de 17/06. (3) "Posição de partida" e "Radar da disputa" reposicionados conforme a separação de mundos. Nenhuma outra regra foi alterada.

> **Nota v10.6 (19/07/2026).** As fontes deste pipeline deixam de ser lista fixa de Sorocaba e passam a vir do **Atlas Municipal + perfil do tenant** (Manual v10.6, Anexo 16). Níveis: **F1** Registrada (CNPJ ativo + CNAE de mídia — identifica o veículo, não mede credibilidade) · **F2** Reconhecida (cobre a cidade/região com evidência arquivada, independente de sede) · **F3** Declarada (influencers/perfis pessoais — só no perfil isolado do tenant, nunca no Atlas). O teste de entrada é **cobertura**, não sede. O motor já lê os dois formatos de perfil (legado e F1/F2/F3).

---

## 1. Saída-alvo — os 7 blocos canônicos

O formato do briefing é definido pelo **perfil do tenant** (`perfil_tatiane.json`) — fonte única, referenciada por Manual, espec e código. Bloco sem dado sai literalmente como **"Sem dado hoje."** — nunca omitido em silêncio, nunca preenchido por suposição.

| # | Bloco | Conteúdo | Natureza |
|---|-------|----------|----------|
| 1 | **Resumo do dia** | Até 3 movimentos que pedem atenção hoje | Síntese (gerado por último) |
| 2 | **Radar de Nomeações (AFEx-g)** | Nomeações/exonerações do Diário Oficial + cruzamento com nomes de interesse | Fiscalização — indício, nunca acusação |
| 3 | **Fiscalização do Executivo** | Contratos acima do limiar do tenant (padrão 25%), base de comparação declarada | Fiscalização |
| 4 | **Pulso da Câmara / Diário Oficial** | Pautas, proposituras e atos em movimento onde ela pode liderar/posicionar | Mandato |
| 5 | **Demandas & Requerimentos** | O que corre no gabinete, mudanças de status, prazos vencidos | Mandato (depende do banco) |
| 6 | **Monitoramento & Imprensa** | Menções e manchetes relevantes, com veículo e data | Monitoramento |
| 7 | **Movimento sugerido (72h)** | Recomendações acionáveis a partir dos blocos acima | Síntese estratégica, sob freio humano |

**Onde foram parar os blocos antigos (v1):**
- *Posição de partida* (votos, colocação, presença digital) — **linha de base de atualização lenta**, fora do briefing diário; vive em tela própria/perfil e é citada quando um item do dia a exigir. *(Decisão registrada na v10.5.)*
- *Radar da disputa* — no mundo Gabinete existe **apenas como leitura de imprensa pública**, dentro do bloco 6. Análise eleitoral estruturada é do mundo Campanha (AIE-p/AIA-p, sob o Nil) e só cruza pela **Ponte Bia↔Nil** auditada.

---

## 2. Mapa fonte → bloco → agente

| Bloco | Fonte de dados | Agente dono | Acesso hoje |
|-------|----------------|-------------|-------------|
| 2 · Radar de Nomeações | Diário Oficial do Município (PDF via COM RMS-001) | AFEx-g | ⚠️ conector COM a construir |
| 3 · Fiscalização | PNCP · bases de preço de referência | AFEx-g | PNCP ✅ (endpoint a confirmar no go-live) |
| 4 · Pulso da Câmara/DO | Portal da Câmara · Câmara Sem Papel/SPL · Diário Oficial · imprensa | AFEx-g + AIM-g | ⚠️ formato a definir (semi-manual até o COM) |
| 5 · Demandas | Banco do gabinete (Supabase) | ADC-g | ❌ banco ainda não no ar |
| 6 · Monitoramento & Imprensa | Imprensa local (5 jornais via agregador) · veículos nacionais · (redes, quando liberado) | AIM-g | Imprensa ✅ · redes ❌ API gated (O5) |
| 1 · Resumo do dia | — (síntese dos blocos 2–6) | Bia-g | ✅ |
| 7 · Movimento 72h | — (síntese estratégica) | Bia-g + ACN-g (tom) | ✅ |

Legenda: ✅ acessível agora · ⚠️ acessível com configuração · ❌ bloqueado (dependência)

---

## 3. Fluxo de geração (madrugada → 06:45)

```
[1] COLETA (rotina noturna)
     cada conector puxa sua fonte:
     Diário Oficial · PNCP · Câmara/SPL · imprensa · (redes, quando liberado)
        │
        ▼
[2] VALIDAÇÃO DE DADOS (Veritas-Dados)
     valida origem + qualidade; recusa dado frágil; anexa fonte e data
        │
        ▼
[3] PROCESSAMENTO POR AGENTE
     AIM-g  → bloco 6 (imprensa e menções)
     AFEx-g → blocos 2, 3, 4 (Diário Oficial + PNCP + Câmara → achados)
     ADC-g  → bloco 5 (demandas, quando o banco subir)
     AAG-g  → agenda pública do dia
     ACN-g  → tom/enquadramento das recomendações
        │
        ▼
[4] SÍNTESE (Bia-g)
     monta bloco 1 (Resumo do dia) + bloco 7 (Movimento 72h)
     a partir dos blocos processados; bloco sem dado = "Sem dado hoje."
        │
        ▼
[5] FREIO HUMANO  ← princípio inviolável
     assessora revisa e aprova antes de qualquer entrega
        │
        ▼
[6] RENDER + ENTREGA 06:45
     HTML/PWA · modo sigiloso · trilha de auditoria registrada
```

---

## 4. Pontos de governança (travas de projeto)

- **Só dados públicos e verificáveis.** Cada apontamento carrega fonte + data de consulta (CVI). Sem isso, não entra.
- **Aprovação humana antes da entrega.** Nenhum briefing sai sem o freio humano (princípio inviolável).
- **Separação dura mandato × campanha.** No mundo -g, radar da disputa é só leitura de imprensa pública (bloco 6). Qualquer análise eleitoral estruturada pertence ao lado Praetor (Nil) e só cruza pela **Ponte Bia↔Nil**, auditada. *(Confirmado na v10.5.)*
- **LGPD não acionada neste produto.** O briefing usa dado público/agregado. O AIM-g nunca trata perfil/grupo privado como público. (O gatilho LGPD está no módulo de Demandas com dado real de cidadão — aguarda parecer.)
- **Rastreabilidade total.** Cada caso e desfecho arquivado com fonte, data e método.

---

## 5. Corte de escopo — o que construímos primeiro

**Fase A — Briefing real com fontes acessíveis (em curso)**
Entrega os blocos **1, 3 (parcial via PNCP), 6 e 7** com automação, e o bloco **4** semi-manual:
- PNCP → fiscalização de contratos (limiar do perfil)
- Imprensa local via agregador → monitoramento
- Blocos 2 e 5 saem como "Sem dado hoje." até as dependências (COM e banco)

**Fase B — Diário Oficial + banco**
- Conector COM RMS-001 (Diário Oficial em PDF) → liga o bloco 2 (Radar de Nomeações) e completa o 4
- Banco Supabase no ar → liga o bloco 5 (Demandas)

**Fase C — Monitoramento ao vivo (operação plena)**
- Redes/social listening (O5) e pauta da Câmara automatizada (SPL)

---

## 6. Dependências que afetam o build

| Dep. | O que falta | Impacto |
|------|-------------|---------|
| O4 / COM | Conector do Diário Oficial de Sorocaba (PDF) | Bloqueia o bloco 2 e a automação plena do 4 |
| Banco | Supabase + RLS no ar | Bloqueia o bloco 5 |
| O5 | APIs de redes ou social listening | Bloqueia o tempo-real do bloco 6 |
| PNCP | Confirmar endpoint/campos da API de consulta no go-live | Ajuste pontual no coletor |

---

## 7. Próximo passo

Motor v2 (dirigido pelo perfil) sincronizado no laptop → rodar o pipeline completo com a chave da API → primeiro briefing 100% gerado pela máquina, no formato dos 7 blocos, pronto para o freio humano. Em paralelo: subir o banco (Etapa 3) e especificar o conector COM.

---

*v1.1 · 18/07/2026 · substitui a v1 (17/06–15/07) · alinhado ao Manual Supremo v10.6 · Confidencial — Eng. Luiz Gonzaga Filho*
