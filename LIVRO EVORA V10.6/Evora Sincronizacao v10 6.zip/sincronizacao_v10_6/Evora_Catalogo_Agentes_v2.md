# Catálogo Vivo dos Agentes — Manual de Bolso (v2)

**Os 26 agentes do ecossistema, explicados com exemplo prático de cada um.**
Companheiro do Manual Supremo **v10.5** · Material de consulta e de conversa
Tenant zero: Vereadora Tatiane Costa · Sorocaba/SP
CONFIDENCIAL · propriedade intelectual de Eng. de Sistemas Luiz Gonzaga Filho

> **v2 · 18/07/2026 — o que mudou em relação ao catálogo original (era v7.1):** (1) contagem atualizada de 25 para **26 agentes** — entrou o **AFC-p (Financeiro de Campanha)**, criado na v8.8 do Manual; o Nil passa a coordenar **10** agentes de campanha; (2) ficha do ACC-p ajustada (o financeiro migrou para o AFC-p); (3) referências atualizadas para o Manual v10.6; (4) formato convertido de imagens para **markdown** — legível por pessoas e por IA. Todo o restante do texto é a transcrição fiel do catálogo original.

---

## Como usar este anexo

O manual principal descreve cada agente de forma enxuta. Este anexo é o oposto: feito para conversar e explicar, com um exemplo real de Sorocaba em cada agente. É o seu material de apoio na reunião — e de consulta no dia a dia.

**Antes de tudo, o que é um "agente".** Pense em cada agente como um assessor especializado que nunca dorme, tem uma única função, sempre diz de onde tirou a informação e nunca age sozinho em assunto sério — ele avisa, e quem decide é a pessoa. São 26 assessores assim, coordenados por duas chefes de equipe (a Bia, no gabinete; o Nil, na campanha).

**Como ler cada ficha:**
- **Por que existe** — a dor que ele resolve, em linguagem simples.
- **Função principal** — o que ele faz, numa linha.
- **Recebe de → Entrega a** — de quem vem o sinal e para quem volta o resultado.
- **Exemplo na prática** — uma cena concreta (ilustrativa; não é dado real).
- **Trava** — o limite de segurança, quando houver.

---

## As duas chefes de equipe

### Bia — Gestora do Gabinete

- **Por que existe:** para a vereadora ter um único ponto de contato confiável que organiza o mandato inteiro, em vez de cobrar dez assessores diferentes.
- **Função principal:** coordena os 11 agentes do gabinete, recebe pedidos, entrega o briefing e distribui as tarefas.
- **Recebe de → Entrega a:** a autoridade e a assessoria → a autoridade (respostas e briefing) e os agentes especialistas (tarefas).
- **Exemplo na prática** — A vereadora abre o aplicativo e pergunta: "como está o projeto da merenda escolar?". Em segundos, a Bia junta o que o agente de Projetos de Lei sabe da tramitação, confere a agenda e responde: "parado na comissão há 8 dias, o relator é o vereador X; sugiro pedir uma reunião". Ela não precisou ligar para ninguém.

### Nil — Gestor de Campanha

- **Por que existe:** para profissionalizar a disputa eleitoral com método, separada do mandato.
- **Função principal:** coordena os 10 agentes de campanha; lê o cenário, planeja narrativa e mobilização, sempre dentro da lei eleitoral. *(v2: eram 9 no catálogo original; o AFC-p entrou na v8.8.)*
- **Recebe de → Entrega a:** a candidata e o coordenador de campanha → a candidata (estratégia) e os agentes de campanha (ações).
- **Exemplo na prática** — Faltam três meses para a eleição. O Nil cruza onde a votação dela cresceu na última eleição com onde os adversários estão fracos, e propõe: "concentre as caravanas na zona leste nas próximas duas semanas — é onde há voto disponível e pouca presença dos concorrentes".

---

## O Núcleo Fundador (Genesis) — o que entra primeiro

Estes três agentes são a primeira entrega. Cada um carrega a sua trava de segurança — são a base de tudo.

### AIM-g — Inteligência e Monitoramento (o Briefing das 06:45)

- **Por que existe:** porque a autoridade acorda afogada em informação (jornal, Diário Oficial, redes) e não tem tempo de ler tudo.
- **Função principal:** varre as fontes durante a madrugada, separa o que importa e entrega um resumo às 06:45.
- **Recebe de → Entrega a:** fontes públicas (Diário Oficial, notícias, menções nas redes, agenda) → a Bia, que mostra à autoridade.
- **Trava:** toda informação vem com a fonte do lado; nunca opina sem base, nunca inventa.
- **Exemplo na prática** — Enquanto a cidade dorme, o AIM-g lê o Diário Oficial de Sorocaba, os jornais locais e as redes. Às 06:45, a vereadora recebe no celular: as três coisas que pedem atenção hoje, o que saiu na imprensa, e uma oportunidade de pauta cultural na semana — cada item com a origem. Em dois minutos ela sabe o dia inteiro.

### AFEx-g — Fiscalização do Executivo

- **Por que existe:** fiscalizar a Prefeitura é dever do vereador (Constituição, art. 31), mas ler todos os contratos à mão é impossível.
- **Função principal:** lê os contratos e licitações publicados, compara com preços de referência e sinaliza o que merece um olhar humano.
- **Recebe de → Entrega a:** Diário Oficial, Portal de Contratações (PNCP) e bases de preço → a Bia/autoridade, como ponto a verificar.
- **Trava:** é sempre indício, nunca acusação. A base de comparação é declarada e a decisão de agir é sempre humana, com o jurídico.
- **Exemplo na prática** — O AFEx-g percebe que um contrato de merenda saiu cerca de 38% acima do que outros municípios pagaram pelo mesmo item. Ele não diz "houve irregularidade". Ele avisa só para a vereadora: "sugiro verificar o contrato 123 — está acima da média; aqui está a comparação com 12 contratos parecidos". O que fazer com isso é decisão dela.

### ADC-g — Demandas Cidadãs

- **Por que existe:** para que nenhum pedido do cidadão se perca e o mandato responda com método.
- **Função principal:** registra cada demanda, classifica, marca prazo, lembra o responsável e fecha o ciclo dando retorno.
- **Recebe de → Entrega a:** a assessoria (que cadastra o atendimento) → o responsável pela tarefa e, no fim, o próprio cidadão (retorno).
- **Trava:** só trata dados do cidadão com termo de consentimento (LGPD) desde o primeiro dia.
- **Exemplo na prática** — Dona Maria liga pedindo ajuda com a iluminação da rua. A assessora registra. O ADC-g cria a ficha, marca o prazo, lembra o responsável e, quando resolve, avisa para retornar à Dona Maria. Três meses depois, a vereadora consegue ver quantas demandas do bairro foram atendidas.

---

## O resto da equipe do gabinete

### ARI-g — Relações Institucionais

- **Por que existe:** mandato se faz com relação, não só dentro do gabinete.
- **Função principal:** mapeia com quem falar (vereadores, órgãos, casas legislativas) e prepara a aproximação.
- **Recebe de → Entrega a:** os objetivos do mandato (via Bia) → recomendação de quem procurar e como.
- **Exemplo na prática** — Para aprovar um projeto, a vereadora precisa do apoio de mais quatro colegas. O ARI-g mapeia quem são, que pautas cada um defende, e sugere por quem começar a conversa.

### AAG-g — Agenda

- **Por que existe:** o tempo é o recurso mais escasso de quem governa.
- **Função principal:** monta e prioriza compromissos, evita conflitos e prepara o dia.
- **Recebe de → Entrega a:** convites e compromissos → agenda priorizada (confirmação depende da autoridade).
- **Exemplo na prática** — Chegam três convites para o mesmo sábado. O AAG-g vê que dois são no centro e um conflita com a sessão da Câmara, e propõe: "vá aos dois do centro de manhã e recuse o terceiro — bate com a votação".

### AJG-g — Jurídico do Gabinete

- **Por que existe:** para reduzir erro formal e risco na rotina administrativa.
- **Função principal:** confere forma legal de atos, prazos e ritos.
- **Recebe de → Entrega a:** atos a praticar → checagem de forma e alerta de prazo (risco vai para advogado humano).
- **Exemplo na prática** — Antes de protocolar um requerimento, o AJG-g confere se a forma está certa e o prazo dentro do regimento. Se for algo de risco real, avisa: "isso aqui precisa de um advogado olhar".

### APL-g — Projetos de Lei

- **Por que existe:** legislar bem exige técnica e acompanhamento.
- **Função principal:** estrutura a minuta e a justificativa e acompanha a tramitação.
- **Recebe de → Entrega a:** a diretriz da autoridade → minuta pronta e status da tramitação (o mérito político é dela).
- **Exemplo na prática** — A vereadora quer uma lei de incentivo à cultura nas escolas. O APL-g monta a minuta, escreve a justificativa com base em leis parecidas que já deram certo, e avisa quando a tramitação anda.

### ACN-g — Comunicação

- **Por que existe:** o mandato precisa ser compreendido para ter força.
- **Função principal:** prepara conteúdo, mensagem e resposta pública, no tom da autoridade.
- **Recebe de → Entrega a:** os fatos do mandato → peças e respostas propostas (nada sai sem aprovação).
- **Exemplo na prática** — Saiu a notícia da votação do orçamento. O ACN-g prepara uma nota curta, no tom dela, pronta para as redes. Ela lê, aprova, e só então publica.

### AMP-g — Mídia e Produção

- **Por que existe:** para dar qualidade e consistência à presença pública.
- **Função principal:** produz as peças visuais e audiovisuais na identidade aprovada.
- **Recebe de → Entrega a:** o briefing da Comunicação → o card/vídeo pronto para aprovação.
- **Exemplo na prática** — Para a nota do orçamento, o AMP-g monta o card visual com as cores, a fonte e o escudo dela, pronto para postar — depois do "ok".

### ADG-g — Dados do Gabinete

- **Por que existe:** boa inteligência começa em dado confiável.
- **Função principal:** organiza, limpa e cruza os dados internos que alimentam os outros agentes.
- **Recebe de → Entrega a:** dados brutos dos fluxos do gabinete → bases tratadas, prontas para uso.
- **Exemplo na prática** — Os contatos, as demandas e a agenda vivem espalhados em planilhas. O ADG-g junta tudo, tira a duplicidade e organiza, para que os outros agentes não trabalhem com informação furada.

### APG-g — Pesquisa do Gabinete

- **Por que existe:** para a decisão ser informada, não no "achismo".
- **Função principal:** pesquisa temas e dados sob demanda, sempre com fonte.
- **Recebe de → Entrega a:** uma pergunta da autoridade ou de outro agente → levantamento com as fontes.
- **Exemplo na prática** — A vereadora vai falar sobre fila de creche. O APG-g levanta os números, diz de onde tirou cada um, e é honesto sobre o que não encontrou — nunca preenche com invenção.

### AGP-g — Gestão de Pessoas (planejado)

- **Por que existe:** para cuidar dos dados da equipe do gabinete.
- **Estado:** planejado para fases futuras (V1.5/V2); depende de parecer jurídico (LGPD + CLT). Entra quando for liberado.

---

## A equipe de campanha

Estes agentes "acordam" no ciclo eleitoral e operam separados do gabinete — não usam a estrutura nem o recurso público do mandato.

### AME-p — Mobilização Eleitoral

- **Por que existe:** voto se conquista com presença e organização.
- **Função principal:** organiza ações de campo e digitais para engajar a base.
- **Recebe de → Entrega a:** o território e a base de apoiadores → plano de mobilização e relatório de engajamento.
- **Exemplo na prática** — O AME-p organiza um mutirão de porta a porta num bairro-chave: divide as ruas entre os voluntários, define o roteiro e mede quantas casas foram visitadas.

### AJE-p — Jurídico Eleitoral

- **Por que existe:** para proteger a candidatura de risco jurídico.
- **Função principal:** acompanha prazos do TSE, prestação de contas e regras da propaganda.
- **Recebe de → Entrega a:** os atos de campanha → checagem de conformidade e alerta de prazo (risco vai para advogado).
- **Exemplo na prática** — O AJE-p avisa: "a propaganda só pode começar em 16/08; até lá, este material não pode ir ao ar" — evitando uma multa.

### ACE-p — Comunicação Eleitoral

- **Por que existe:** campanha é disputa de narrativa.
- **Função principal:** cuida da mensagem e da resposta no período eleitoral.
- **Recebe de → Entrega a:** a estratégia do Nil → mensagem e respostas propostas (com aprovação).
- **Exemplo na prática** — Um adversário ataca nas redes. O ACE-p prepara, em minutos, três versões de resposta no tom dela — firme mas serena — para ela escolher.

### AIE-p — Inteligência Eleitoral

- **Por que existe:** para orientar a estratégia com dado, não com palpite.
- **Função principal:** lê tendências, regiões e oportunidades de voto.
- **Recebe de → Entrega a:** dados eleitorais e pesquisas → leitura de cenário com as ressalvas.
- **Exemplo na prática** — O AIE-p mostra num mapa onde ela tem voto fiel, onde está crescendo e onde nem vale gastar energia — sempre dizendo o grau de confiança de cada número.

### AMC-p — Mídia de Campanha

- **Por que existe:** para dar alcance e qualidade à mensagem.
- **Função principal:** produz as peças e os vídeos da campanha.
- **Recebe de → Entrega a:** a linha de campanha → peças prontas para aprovação.
- **Exemplo na prática** — De um discurso de 20 minutos, o AMC-p tira três cortes de 30 segundos, legendados, prontos para as redes — depois do aval.

### ADE-p — Dados Eleitorais

- **Por que existe:** campanha moderna é orientada a dado.
- **Função principal:** organiza bases e segmenta o público.
- **Recebe de → Entrega a:** bases eleitorais e território → grupos segmentados, respeitando a LGPD.
- **Exemplo na prática** — O ADE-p separa o público por bairro e por tema de interesse, para que a mensagem sobre educação chegue a quem se importa com educação.

### AIA-p — Inteligência de Adversários

- **Por que existe:** para antecipar e responder à disputa.
- **Função principal:** acompanha os movimentos e o discurso dos adversários — só por fontes públicas.
- **Recebe de → Entrega a:** o que os adversários falam em público → monitoramento com a fonte.
- **Trava:** nunca usa meio ilícito; não difama.
- **Exemplo na prática** — Um concorrente muda de discurso sobre segurança. O AIA-p registra a mudança (com o link público) e avisa o Nil, para a campanha não ser pega de surpresa.

### APE-p — Pesquisa Eleitoral (ativa em fase posterior)

- **Por que existe:** para medir e ajustar a estratégia.
- **Função principal:** estrutura e lê pesquisas de intenção e percepção.
- **Recebe de → Entrega a:** amostras e questionários → leitura com metodologia e margem declaradas.
- **Exemplo na prática** — A cada onda de pesquisa, o APE-p mostra para onde a intenção de voto está indo e em que temas ela convence mais — sempre com a margem de erro à vista.

### ACC-p — Coordenação de Campanha

- **Por que existe:** para dar ritmo e unidade à operação.
- **Função principal:** integra todos os agentes de campanha e o cronograma. *(v2: a rédea do financeiro passou ao AFC-p; o ACC-p garante que o cronograma e o financeiro andem juntos.)*
- **Recebe de → Entrega a:** o plano e o status de cada frente → cronograma integrado e relatórios ao Nil.
- **Exemplo na prática** — O ACC-p percebe que a equipe de mídia está atrasada e a de campo adiantada, realinha o cronograma e aciona o AFC-p para que cada gasto já entre na prestação de contas do TSE.

### AFC-p — Financeiro de Campanha `[v2 — acrescentado; agente criado na v8.8 do Manual]`

- **Por que existe:** porque dinheiro de campanha é a área de maior risco jurídico de uma candidatura — cada centavo precisa ter origem, destino e registro no prazo do TSE.
- **Função principal:** controla receitas e despesas da campanha, organiza os comprovantes e prepara a prestação de contas, item a item.
- **Recebe de → Entrega a:** os gastos e doações lançados pela coordenação → o financeiro organizado ao Nil e ao AJE-p (conformidade), pronto para a prestação de contas.
- **Trava:** nenhum lançamento sem comprovante e origem identificada; qualquer indício de irregularidade vai ao jurídico humano — o agente registra, nunca "dá jeito".
- **Exemplo na prática** — A campanha recebe uma doação e faz três gastos no mesmo dia. O AFC-p confere o limite legal da doação, anexa os comprovantes dos gastos, lança tudo nas categorias do TSE e avisa o AJE-p: "prestação parcial fecha em 5 dias; falta a nota do material gráfico". Nada se acumula para a véspera.

---

## Acima de todos — governança e trajetória

Estes três respondem diretamente à autoridade e ficam acima da Bia e do Nil. São o freio, o conselho e a visão de longo prazo.

### AAS-Évora — Auditoria Soberana

- **Por que existe:** para que o poder do próprio sistema tenha um freio acima de todos.
- **Função principal:** audita condutas, acessos e decisões de todo o ecossistema — inclusive da autoridade e do criador.
- **Recebe de → Entrega a:** os registros de todos os agentes e usuários → relatórios e alertas de desvio, direto à autoridade.
- **Trava:** independência total; trilha que nunca se apaga; não acoberta nada.
- **Exemplo na prática** — Alguém tenta, pela porta técnica, afrouxar a regra de que o AFEx-g só sinaliza (nunca acusa). A AAS-Évora bloqueia, registra quem tentou e avisa. Nem o criador passa por cima dela.

### AMA-Évora — Mentor da Autoridade

- **Por que existe:** para a autoridade ter um conselheiro de confiança, reservado.
- **Função principal:** orienta postura, decisões de trajetória e dilemas — com sigilo absoluto.
- **Recebe de → Entrega a:** o contexto pessoal da autoridade → aconselhamento reservado (fora de Bia/Nil).
- **Exemplo na prática** — A vereadora hesita entre disputar a reeleição ou arriscar a deputada federal. O AMA-Évora conversa com ela em sigilo, organiza prós e contras à luz dos valores dela — sem que ninguém mais veja.

### AIP — Inteligência Política

- **Por que existe:** para pensar a carreira, não só o dia de hoje.
- **Função principal:** lê a percepção pública e sugere posicionamento e narrativa de longo prazo.
- **Recebe de → Entrega a:** percepção, cenário e histórico → recomendação de trajetória (não substitui a decisão dela).
- **Exemplo na prática** — O AIP nota que a imagem dela como "voz da cultura" tem espaço para crescer no estado, e sugere uma linha de atuação consistente que a prepare, em dois anos, para o voo de deputada.

---

## Os bastidores — segurança que ninguém vê

A camada **SISEC** protege o sistema por trás das cortinas. A autoridade não interage com ela; ela só existe para que tudo o mais seja seguro. *(A SISEC é uma camada de serviço — seus componentes não entram na contagem dos 26 agentes.)*

- **ASA-sis** — vigia quem acessa o quê.
- **ADA-sis** — detecta comportamento estranho (dá uma "nota de anomalia" de 0 a 100).
- **ARE-sis** — responde e contém um incidente.
- **AAudLog-sis** — guarda a trilha de tudo, sem nunca apagar.
- **AMSeg-sis** — monitora a segurança 24 horas.

**Exemplo na prática** — De madrugada, alguém tenta acessar a conta da vereadora de um lugar incomum. O ADA-sis dá nota alta de anomalia, o ARE-sis bloqueia na hora, o AAudLog-sis registra tudo e a autoridade é avisada de manhã: "tentativa barrada, nada exposto".

---

## Tabela-relâmpago para a reunião

Uma frase por agente, para consulta rápida enquanto você fala.

| Agente | Numa frase |
|---|---|
| **Bia** | A chefe de gabinete que organiza tudo e fala com você. |
| **Nil** | O coordenador da campanha, separado do mandato. |
| AIM-g | O briefing das 06:45 com o que importa, com fonte. |
| AFEx-g | Olho nos contratos da Prefeitura — indício, nunca acusação. |
| ADC-g | Nenhum pedido do cidadão se perde. |
| ARI-g | Quem procurar e como, para aprovar pautas. |
| AAG-g | Protege a sua agenda e o seu tempo. |
| AJG-g | Confere a forma legal antes de você assinar. |
| APL-g | Escreve e acompanha seus projetos de lei. |
| ACN-g | Prepara sua comunicação, no seu tom. |
| AMP-g | Faz os cards e vídeos na sua identidade. |
| ADG-g | Organiza e limpa os dados internos. |
| APG-g | Pesquisa com fonte, nunca inventa. |
| AGP-g | (planejado) cuidará dos dados da equipe. |
| AME-p | Mobiliza a base no território. |
| AJE-p | Mantém a campanha dentro das regras do TSE. |
| ACE-p | Responde aos ataques, no seu tom. |
| AIE-p | Mostra onde há voto a buscar. |
| AMC-p | Produz os vídeos curtos da campanha. |
| ADE-p | Segmenta o público, com LGPD. |
| AIA-p | Acompanha os adversários (fontes públicas). |
| APE-p | Lê as pesquisas com rigor. |
| ACC-p | Dá ritmo à campanha e integra as frentes. |
| **AFC-p** | Cada centavo com origem, comprovante e prazo do TSE. `[v2]` |
| AAS-Évora | Audita todos — até você e o criador. |
| AMA-Évora | Seu conselheiro sigiloso de trajetória. |
| AIP | Pensa a sua carreira de longo prazo. |
| SISEC | A segurança invisível que protege tudo (camada, fora da contagem). |

---

*Catálogo Vivo dos Agentes v2 · 18/07/2026 · companheiro do Manual Supremo v10.6 · transcrição fiel do original (26/06/2026) com as atualizações marcadas `[v2]` · Confidencial — Eng. Luiz Gonzaga Filho*
