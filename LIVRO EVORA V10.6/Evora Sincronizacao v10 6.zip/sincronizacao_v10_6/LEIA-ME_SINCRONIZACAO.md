# Pacote de Sincronização — Évora v10.6 (19/07/2026)

Este pacote deixa a pasta do projeto alinhada ao **Manual Supremo v10.6**.
Substitui o pacote v10.5 emitido em 18/07 (mesmos arquivos, sem o Anexo 16).

## Antes de tudo (regra de ouro)
```powershell
Copy-Item motor motor_backup_20260719 -Recurse   # backup — nada se apaga
```

## O que mudou nesta emissão (v10.5 -> v10.6)

O Manual ganhou o **Anexo 16 — Atlas Municipal do Brasil e Entrevista de Fundação**, que torna
o Évora instalável em qualquer município do Brasil. Consequências no código:

| Novidade | Onde |
|---|---|
| **`entrevista_fundacao.py`** — as 14 perguntas do onboarding, gera o perfil do tenant | `motor\` (NOVO) |
| **Níveis de fonte F1/F2/F3** (CNPJ identifica; cobertura decide entrada) | `perfil_tatiane.json`, `perfil_tenant_modelo.json` |
| **Multi-município** (`municipio_sede` + `area_atuacao`) | ambos os perfis + `perfil_loader_evora.py` |
| **Procedência por campo** (`declarado` / `atlas` / `verificado`) | ambos os perfis |
| Loader lê os dois formatos de veículo e exclui F3 da varredura geral | `perfil_loader_evora.py` |

## O que substitui o quê

| Arquivo novo (neste pacote) | Substitui | Mudança |
|---|---|---|
| `motor\entrevista_fundacao.py` | — (novo) | Onboarding do tenant: 14 perguntas → perfil (decisão D7) |
| `motor\atlas_municipal.py` + `motor\atlas_sorocaba-sp.json` | — (novo) | Atlas Municipal em arquivo: `semear` cidade nova, `aplicar` ao perfil (procedência `atlas`), `validar` regras do Anexo 16. Sorocaba já semeada (5 F1 + 1 F2 com evidência, DO verificado) |
| `motor\perfil_loader_evora.py` | versão v10.5 | Ganhou `area_atuacao()` e normalização F1/F2/F3 — **retrocompatível** |
| `motor\perfil_tatiane.json` | versão v10.5 | Níveis de fonte, procedência, multi-município |
| `motor\perfil_tenant_modelo.json` | versão v10.5 | Folha em branco com a estrutura nova |
| `motor\*.py` (demais scripts) | scripts de 13/07 | motor v2: dirigido pelo perfil, limiar do perfil, render corrigido, orquestrador honesto |
| `motor\render_dashboard_evora.py` + `motor\dashboard_template.html` | — | Dashboard real: painéis Briefing, Radar e Fiscalização com dados do dia (5º passo do orquestrador) |
| `Briefing_Matinal_Pipeline_v1_1.md` | `Briefing_Matinal_Pipeline_v1.md` | AFEx-g; 7 blocos canônicos; **nota v10.6 sobre fontes por cidade** |
| `GUIA_Primeiro_Briefing_v2.md` | guia "v9.9" | Sem pip; PowerShell + Mac/Linux; **Parte 0 — Entrevista de Fundação** |
| `Evora_Catalogo_Agentes_v2.md` | catálogo .pdf (ZIP de imagens) | 26 agentes (entrou AFC-p); markdown legível por IA |
| `ROTEIRO_LAPTOP_APOSENTADO.md` | `ROTEIRO_LAPTOP_v3.md` | Roteiro aposentado; instruções v2 assumem |
| `renomear_versoes.ps1` | — | Higiene: arquiva duplicatas com carimbo de data |

## Depois de copiar

1. Rodar `renomear_versoes.ps1` na pasta dos documentos (arquiva duplicatas, inclusive a v10.5).
2. Testar o motor: `python motor\perfil_loader_evora.py` -> deve mostrar "Limiar: 25%" e 7 blocos.
3. Rodar o pipeline com a chave (`GUIA_Primeiro_Briefing_v2.md`, Parte 3).
4. Conferir que `Dashboard_Real_AAAAMMDD.html` foi gerado junto.
5. **Tenant novo:** rodar `python motor\entrevista_fundacao.py` (Parte 0 do guia); depois `python motor\atlas_municipal.py semear "<Cidade>" <UF>`, preencher/verificar, e `aplicar` ao perfil.
6. Quando o Git subir, este pacote é o commit inicial ("consolidação v10.6").

## Estado honesto do que está aqui

| Componente | Estado |
|---|---|
| Motor de briefing (coleta -> Bia -> render) | **Roda** |
| Dashboard real (3 painéis) | **Roda** |
| Entrevista de Fundação | **Roda** — gera perfil consumível pelo motor; testada com e sem ciência das travas |
| Atlas Municipal (`atlas_municipal.py`) | **Roda (versão em arquivo)** — semear/aplicar/validar; Sorocaba semeada com dados verificados (`atlas_sorocaba-sp.json`); migra para o banco na Etapa 3 sem mudar estrutura |
| Conector do Diário Oficial (COM) | **A escrever** — nenhuma cidade tem conector, nem Sorocaba |
| Banco Supabase (11 tabelas + RLS) | **A escrever** — Etapa 3 |

*Confidencial — Eng. Luiz Gonzaga Filho · alinhado ao Manual Supremo v10.6 de 19/07/2026*
