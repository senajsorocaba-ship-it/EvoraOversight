#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ÉVORA OVERSIGHT — Renderizador do Briefing (motor v2 · markdown -> HTML on-brand)
=================================================================================
Pega o briefing_AAAAMMDD.md (escrito pela Bia) e gera um HTML no padrão visual
do Évora (navy + dourado), pronto para ler no celular às 06h45.

Mudança v2 (achado C6 da Revisão): a conversão agora usa uma MÁQUINA DE
BLOCOS explícita — abre <div class="block"> a cada "## " e fecha o anterior
por estado, sem o replace frágil que deixava </div> órfão quando havia
"# título" ou parágrafo antes do primeiro bloco.

Só biblioteca padrão. USO:
  python3 render_briefing_evora.py            (briefing de hoje)
  python3 render_briefing_evora.py arquivo.md (um específico)
"""
import sys, re, html
from datetime import date

CSS = """
:root{--navy:#213A5C;--gold:#B5985A;--cream:#F4F1EA;--paper:#FBFAF6;--ink:#23272e;--mut:#5b6470;--line:#E4DED1}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--cream);color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;line-height:1.55}
.wrap{max-width:620px;margin:0 auto;padding-bottom:50px}
.top{background:var(--navy);color:#fff;padding:18px}
.bname{font-family:Georgia,serif;letter-spacing:.26em;font-size:12px}
.bname b{color:var(--gold)}
.btitle{font-family:Georgia,serif;font-size:22px;margin-top:8px}
.bsub{font-size:12.5px;color:#b9c6d6;margin-top:2px}
.block{margin:16px 14px 0;background:var(--paper);border:1px solid var(--line);border-radius:9px;padding:14px 16px}
h1{display:none}
h2{font-family:Georgia,serif;font-size:16px;color:var(--navy);margin:0 0 8px;padding-bottom:6px;border-bottom:1px solid var(--line)}
ul,ol{margin:4px 0 0 18px}li{font-size:14px;margin:5px 0}
p{font-size:14px;margin:6px 0}
blockquote{margin:10px 14px 0;padding:10px 12px;background:#EEF2F7;border-left:3px solid var(--gold);font-size:13px;color:var(--mut);border-radius:0 8px 8px 0}
strong{color:var(--navy)}
.foot{margin:18px 14px 0;font-size:11px;color:var(--mut);text-align:center;line-height:1.6}
hr{border:0;border-top:1px solid var(--line);margin:14px}
em{color:var(--mut)}
"""


def _inline(s):
    s = html.escape(s)
    s = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", s)
    s = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"<em>\1</em>", s)
    return s


def md_to_html(md):
    """Máquina de blocos: estado explícito para lista, bloco e citação."""
    out = []
    in_ul = in_block = in_quote = False

    def fecha_ul():
        nonlocal in_ul
        if in_ul:
            out.append("</ul>")
            in_ul = False

    def fecha_quote():
        nonlocal in_quote
        if in_quote:
            out.append("</blockquote>")
            in_quote = False

    def fecha_block():
        nonlocal in_block
        fecha_ul()
        fecha_quote()
        if in_block:
            out.append("</div>")
            in_block = False

    for raw in md.splitlines():
        line = raw.rstrip()
        s = line.strip()
        if not s:
            fecha_ul()
            fecha_quote()
            continue
        if s.startswith("# ") and not s.startswith("## "):
            fecha_block()
            out.append(f"<h1>{_inline(s[2:])}</h1>")
        elif s.startswith("## "):
            fecha_block()
            out.append(f'<div class="block"><h2>{_inline(s[3:])}</h2>')
            in_block = True
        elif s.startswith("> "):
            fecha_ul()
            if not in_quote:
                out.append("<blockquote>")
                in_quote = True
            out.append(f"<p>{_inline(s[2:])}</p>")
        elif s.startswith(("- ", "* ")):
            fecha_quote()
            if not in_ul:
                out.append("<ul>")
                in_ul = True
            out.append(f"<li>{_inline(s[2:])}</li>")
        elif re.match(r"^\d+\.\s", s):
            fecha_quote()
            if not in_ul:
                out.append("<ul>")
                in_ul = True
            out.append(f"<li>{_inline(re.sub(r'^\\d+\\.\\s*', '', s))}</li>")
        elif s in ("---", "***", "___"):
            fecha_ul()
            fecha_quote()
            out.append("<hr>")
        else:
            fecha_ul()
            fecha_quote()
            out.append(f"<p>{_inline(s)}</p>")
    fecha_block()
    return "\n".join(out)


def main():
    arq = sys.argv[1] if len(sys.argv) > 1 else f"briefing_{date.today().strftime('%Y%m%d')}.md"
    try:
        md = open(arq, encoding="utf-8").read()
    except FileNotFoundError:
        raise SystemExit(f"Arquivo não encontrado: {arq} (rode antes o montador).")
    corpo = md_to_html(md)
    page = f"""<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Briefing Matinal — Évora</title><style>{CSS}</style></head><body>
<div class="wrap">
  <div class="top">
    <div class="bname">ÉVORA <b>GABINETE</b></div>
    <div class="btitle">Briefing Matinal</div>
    <div class="bsub">{date.today().strftime('%d/%m/%Y')} · 06h45 · gerado pela Bia a partir de fontes públicas</div>
  </div>
  {corpo}
  <div class="foot">ÉVORA OVERSIGHT · cada item com origem declarada · uso interno do gabinete<br>Indício é para verificação humana — nunca acusação.</div>
</div></body></html>"""
    saida = arq.replace(".md", ".html")
    open(saida, "w", encoding="utf-8").write(page)
    print(f"✓ Briefing renderizado em {saida}")


if __name__ == "__main__":
    main()
