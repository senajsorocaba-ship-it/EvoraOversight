#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ÉVORA OVERSIGHT — Montador do Briefing Matinal (motor v2 — a Bia escreve via API)
=================================================================================
Pega o que os coletores juntaram (PNCP + imprensa) e a BIA escreve o Briefing
no formato do PERFIL DO TENANT (identidade, tom, 7 blocos e Caráter Travado
vêm de perfil_tatiane.json — Manual v10.4, formato canônico).

Mudanças v2 (achados C1, C3, C4 da Revisão):
  C1 — lê o perfil; system prompt gerado do perfil; blocos sem dado = "Sem dado hoje."
  C3 — instrução Windows correta: PowerShell  $env:ANTHROPIC_API_KEY = "sua-chave"
       (setx só vale para janelas NOVAS; não use para a sessão atual)
       Mac/Linux:  export ANTHROPIC_API_KEY="sua-chave"
  C4 — sem internet/DNS, sai mensagem clara em vez de traceback bruto.

Entradas: contratos_sorocaba.json · noticias.json (o que faltar vira "Sem dado hoje.")
Saída:    briefing_AAAAMMDD.md
Só biblioteca padrão. Requer ANTHROPIC_API_KEY no ambiente (pago por uso).
"""
import os, json, urllib.request, urllib.error
from datetime import date

from perfil_loader_evora import carregar_perfil, blocos, autoridade

MODELO  = "claude-sonnet-4-6"   # bom custo/qualidade; alternativa: claude-opus-4-8
MAX_TOK = 2500
API_URL = "https://api.anthropic.com/v1/messages"


def sistema_do_perfil(p):
    """Monta a 'constituição' da Bia a partir do perfil do tenant (fonte única)."""
    a = autoridade(p)
    br = p.get("briefing", {}) or {}
    quem = f"{a.get('cargo_atual','')} {a.get('nome','')} ({a.get('partido','')}, " \
           f"{a.get('municipio','')}/{a.get('uf','')})".strip()
    pre = a.get("pre_candidatura_2026", "")
    if pre:
        quem += f", pré-candidata a {pre} 2026"
    tom = br.get("tom", "factual, conciso, respeitoso; sem opinião pessoal nem recomendação de voto")
    carater = br.get("carater", "Sem invenção; fonte declarada em tudo; 'não sei' é válido; freio humano.")
    lista_blocos = "\n".join(f"## {b}" for b in blocos(p))
    return f"""Você é a Bia, Gestora do Gabinete na plataforma Évora Oversight.
Sua tarefa: escrever o Briefing Matinal de {quem}, a partir SOMENTE dos dados fornecidos.

REGRAS INVIOLÁVEIS (Cláusula de Caráter Travado do tenant):
{carater}
- Não invente nada. Use apenas os dados recebidos.
- Bloco sem dado recebido sai EXATAMENTE como: "Sem dado hoje." (integridade, não falha).
- Cada item relevante cita a fonte/origem e a data.
- Tom: {tom}
- Fiscalização é sempre "indício para acompanhar, NUNCA acusação", com base de comparação declarada.
- Marque relevância quando útil (Rotina / Atenção).
- "Movimento sugerido (72h)" traz sugestões que dependem de APROVAÇÃO HUMANA (freio humano).

FORMATO (markdown, TODOS os blocos, nesta ordem exata — os sem dado com "Sem dado hoje."):
# Briefing Matinal — {{data}}
{lista_blocos}
Seja objetivo — isto é lido às {br.get('horario','06:45')} no celular."""


def carregar(caminho):
    if not os.path.exists(caminho):
        return None
    try:
        with open(caminho, encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return None


def _brl(v):
    return f"R$ {v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def resumir_contratos(contratos, top=8):
    if not contratos:
        return "SEM DADO (coletor PNCP não trouxe contratos hoje)."
    total = sum(c.get("valor", 0) for c in contratos)
    maiores = sorted(contratos, key=lambda c: c.get("valor", 0), reverse=True)[:top]
    linhas = [f"Total: {len(contratos)} contratos somando {_brl(total)}"]
    for c in maiores:
        linhas.append(f"- {_brl(c.get('valor', 0))} | {c.get('objeto','—')[:70]}"
                      f" | órgão: {c.get('orgao','—')} | fornecedor: {c.get('fornecedor','—')}"
                      f" | {c.get('relevancia','')} | publicado: {c.get('data_publicacao','—')}"
                      + (f" | INDÍCIO: {c['indicio']}" if c.get("indicio") else ""))
    return "\n".join(linhas)


def resumir_noticias(noticias, top=14):
    if not noticias:
        return "SEM DADO (coletor de imprensa não trouxe notícias hoje)."
    return "\n".join(
        f"- {n.get('titulo','—')} | fonte: {n.get('fonte','—')} | {n.get('data','')}"
        for n in noticias[:top]
    )


def montar_mensagem(contratos, noticias):
    return f"""Dados de hoje para o briefing (o que estiver marcado SEM DADO vira "Sem dado hoje." no bloco).

[FISCALIZAÇÃO — contratos públicos (PNCP)]
{resumir_contratos(contratos)}

[IMPRENSA — notícias coletadas]
{resumir_noticias(noticias)}

[DEMAIS BLOCOS] Radar de Nomeações, Pulso da Câmara/DO e Demandas ainda não têm coletor ligado — use "Sem dado hoje.", salvo o que a imprensa acima sustentar com fonte.

Escreva o Briefing Matinal seguindo o formato e as regras. Data de hoje: {date.today().strftime('%d/%m/%Y')}."""


def chamar_api(sistema, mensagem):
    chave = os.environ.get("ANTHROPIC_API_KEY")
    if not chave:
        raise SystemExit(
            "⚠️  Defina a ANTHROPIC_API_KEY antes de rodar.\n"
            '   Windows (PowerShell, vale nesta janela):  $env:ANTHROPIC_API_KEY = "sua-chave"\n'
            '   Mac/Linux:                                export ANTHROPIC_API_KEY="sua-chave"'
        )
    corpo = json.dumps({
        "model": MODELO,
        "max_tokens": MAX_TOK,
        "system": sistema,
        "messages": [{"role": "user", "content": mensagem}],
    }).encode("utf-8")
    req = urllib.request.Request(API_URL, data=corpo, headers={
        "x-api-key": chave,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    })
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            dados = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detalhe = e.read().decode("utf-8", "replace")[:300]
        dica = {401: "chave errada ou com espaço extra (refaça o $env:/export)",
                402: "falta cartão/crédito no console (Billing)",
                429: "limite de uso atingido (aguarde ou ajuste o limite no console)"}.get(e.code, "")
        raise SystemExit(f"Erro da API ({e.code}){' — ' + dica if dica else ''}: {detalhe}")
    except urllib.error.URLError as e:
        raise SystemExit(
            f"⚠️  Sem conexão com a API ({e.reason}).\n"
            "   Verifique a internet/proxy e rode de novo. Nada foi gerado — "
            "degradar avisando, nunca falhar em silêncio."
        )
    partes = [b.get("text", "") for b in dados.get("content", []) if b.get("type") == "text"]
    return "\n".join(partes).strip()


def main():
    p = carregar_perfil()
    print(f"→ Perfil do tenant: {p.get('tenant')}  ({p['_arquivo']})")
    print("→ Carregando dados dos coletores...")
    contratos = carregar("contratos_sorocaba.json")
    noticias = carregar("noticias.json")
    if not contratos and not noticias:
        print("  ⚠ Nenhum dado dos coletores — o briefing sairá com blocos 'Sem dado hoje.'")

    print("→ A Bia está escrevendo o briefing (API da Claude)...\n")
    texto = chamar_api(sistema_do_perfil(p), montar_mensagem(contratos, noticias))
    print(texto)

    nome = f"briefing_{date.today().strftime('%Y%m%d')}.md"
    with open(nome, "w", encoding="utf-8") as f:
        f.write(texto + "\n")
    print(f"\n✓ Briefing salvo em {nome}")


if __name__ == "__main__":
    main()
