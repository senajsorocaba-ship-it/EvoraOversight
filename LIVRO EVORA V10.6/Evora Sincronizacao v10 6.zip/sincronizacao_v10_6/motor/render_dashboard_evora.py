"""
Évora Oversight — Render Dashboard Real (motor_v2)
====================================================
Injeta dados REAIS (do briefing do dia + fiscalização PNCP) nos painéis
"Briefing", "Radar de Nomeações" e "Fiscalização" do Dashboard Geral v1
(protótipo visual recuperado do WhatsApp em 15/07/2026).

Caráter Travado aplicado aqui, não só no motor de briefing:
  - Nunca inventa. Se não há dado real para um painel, o painel mostra
    "Sem dado hoje" com o motivo (conector pendente, sem rede, etc.).
  - Cada item real carrega fonte + data no corpo do texto (CVI).
  - Este script NÃO decide sozinho o que é "achado" — apenas formata
    o que o motor (montador_briefing_evora.py + coletor_pncp_evora.py)
    já coletou e validou.

Escopo desta versão (decisão do fundador, 19/07/2026):
    Painéis tornados reais agora -> Briefing, Radar de Nomeações, Fiscalização
    Painéis que continuam protótipo -> todos os demais (Demandas, Agenda,
    Bia IA, lado Campanha etc.) — dependem do banco (Etapa 3) ou de
    conectores ainda não construídos. Nada neles foi tocado.

Uso:
    from render_dashboard_evora import renderizar_dashboard
    renderizar_dashboard(template_path, saida_path, dados_reais)

`dados_reais` é um dict com estas chaves (todas opcionais — o que faltar
vira "Sem dado hoje" automaticamente):
    {
      "data_referencia": "19/07/2026",
      "briefing": [ [status, titulo, corpo_com_fonte], ... ],
      "radar":    [ [status, titulo, corpo_com_fonte], ... ]  ou None,
      "fiscalizacao": [ [status, titulo, corpo_com_fonte], ... ] ou None,
      "alertas":  [ {"p":status, "t":titulo, "o":origem, "m":"gab"}, ... ],
    }
status válido: "cr" (crítico) · "at" (atenção) · "ok" (ok) · "in" (informativo)
"""

import json
import re
from pathlib import Path


def _extrair_bloco_D(html: str):
    """Localiza `const D={...};` por contagem de chaves (robusto a strings
    com { } dentro). Retorna (inicio_chave, fim_chave, dict_D)."""
    marca = html.find("const D=")
    if marca == -1:
        raise ValueError("Não encontrei 'const D=' no template — o dashboard mudou de formato?")
    inicio = html.find("{", marca)
    depth = 0
    in_str = False
    esc = False
    fim = None
    for j in range(inicio, len(html)):
        c = html[j]
        if in_str:
            if esc:
                esc = False
            elif c == "\\":
                esc = True
            elif c == '"':
                in_str = False
            continue
        if c == '"':
            in_str = True
        elif c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                fim = j
                break
    if fim is None:
        raise ValueError("JSON de const D não fechou corretamente — arquivo corrompido?")
    blob = html[inicio : fim + 1]
    return inicio, fim, json.loads(blob)


def _sem_dado(motivo: str, fonte: str, data_ref: str):
    return [["in", "Sem dado hoje", f"{motivo} Fonte da checagem: {fonte}, consultado em {data_ref}."]]


def _set_selo(D: dict, mundo: str, item_id: str, valor):
    """Ajusta (ou remove) o selo numérico da barra lateral para um item.
    valor=None remove o selo (nunca mostrar contagem que não é real)."""
    for grupo in D.get(mundo, []):
        for item in grupo.get("itens", []):
            if item.get("id") == item_id:
                if valor is None:
                    item.pop("selo", None)
                else:
                    item["selo"] = str(valor)
                return
    # item não encontrado — não é erro fatal, só não há selo pra ajustar


def renderizar_dashboard(template_path: str, saida_path: str, dados_reais: dict):
    html = Path(template_path).read_text(encoding="utf-8")
    inicio, fim, D = _extrair_bloco_D(html)

    data_ref = dados_reais.get("data_referencia", "hoje")

    # --- Briefing (g_brief) ---------------------------------------------
    briefing_itens = dados_reais.get("briefing")
    if not briefing_itens:
        briefing_itens = _sem_dado(
            "O motor ainda não gerou o briefing de hoje.",
            "orquestrador_evora.py", data_ref,
        )
    D["cont"]["g_brief"] = [
        "❋", "Briefing Matinal",
        f"AIM-g — Inteligência e Monitoramento · dados reais de {data_ref}",
        briefing_itens,
    ]

    # --- Radar de Nomeações (g_radar) ------------------------------------
    radar_itens = dados_reais.get("radar")
    if not radar_itens:
        radar_itens = _sem_dado(
            "O conector do Diário Oficial (COM RMS-001) ainda não está no ar.",
            "noticias.sorocaba.sp.gov.br/jornal", data_ref,
        )
        _set_selo(D, "gab", "g_radar", None)
    else:
        achados = sum(1 for it in radar_itens if it[0] in ("cr", "at"))
        _set_selo(D, "gab", "g_radar", achados if achados else None)
    D["cont"]["g_radar"] = [
        "◎", "Radar de Nomeações",
        "AFEx-g — Fiscalização do Executivo",
        radar_itens,
    ]

    # --- Fiscalização (g_fisc) -------------------------------------------
    fisc_itens = dados_reais.get("fiscalizacao")
    if not fisc_itens:
        fisc_itens = _sem_dado(
            "O coletor PNCP roda só com internet do laptop; não houve execução hoje.",
            "coletor_pncp_evora.py", data_ref,
        )
        _set_selo(D, "gab", "g_fisc", None)
    else:
        criticos = sum(1 for it in fisc_itens if it[0] in ("cr", "at"))
        _set_selo(D, "gab", "g_fisc", criticos if criticos else None)
    D["cont"]["g_fisc"] = [
        "◇", "Fiscalização",
        "AFEx-g · limiar 25% · indício, nunca acusação",
        fisc_itens,
    ]

    # --- Alertas (feed superior) ------------------------------------------
    if "alertas" in dados_reais:
        D["alertas"] = dados_reais["alertas"]

    novo_blob = json.dumps(D, ensure_ascii=False)
    novo_html = html[:inicio] + novo_blob + html[fim + 1 :]
    Path(saida_path).write_text(novo_html, encoding="utf-8")
    return saida_path


# =====================================================================
# PRODUÇÃO — 4º passo do orquestrador (roda todo dia, sem intervenção)
# =====================================================================
#
# Não exige mudar o montador nem o formato do briefing: lê o
# briefing_AAAAMMDD.md que já existe (texto em markdown, escrito pela
# Bia) e recorta os blocos "## Resumo do dia", "## Radar de Nomeações
# (AFEx-g)" e "## Fiscalização do Executivo" — os mesmos 3 que o
# fundador decidiu tornar reais em 19/07/2026. O resto do dashboard
# continua protótipo até o banco (Etapa 3) subir.
#
# Se o bloco do markdown já é "Sem dado hoje" (o motor degradou
# honestamente por falta de coletor/rede), o dashboard herda esse
# "Sem dado hoje" — nunca inventa por cima.

_CABECALHOS = {
    "Resumo do dia": "briefing",
    "Radar de Nomeações (AFEx-g)": "radar",
    "Fiscalização do Executivo (indício, nunca acusação)": "fiscalizacao",
}


def _split_headline_corpo(linha: str):
    """'- **Título** — resto do texto.' -> ('Título', 'resto do texto.')
    Se não achar negrito, usa as primeiras ~8 palavras como título."""
    if linha.startswith("- "):
        linha = linha[2:]
    linha = linha.strip()
    m = re.match(r"\*\*(.+?)\*\*\s*[—\-:]?\s*(.*)", linha)
    if m:
        titulo, corpo = m.group(1).strip(), m.group(2).strip()
        return titulo, corpo if corpo else titulo
    palavras = linha.split()
    titulo = " ".join(palavras[:8]) + ("…" if len(palavras) > 8 else "")
    return titulo, linha


def _status_da_linha(linha: str):
    # status vem do CONTEÚDO DO ITEM, nunca do bloco inteiro — um bloco
    # pode ter uma frase "sem dado do PNCP hoje" no topo e, logo abaixo,
    # itens de contexto que são reais e têm fonte própria.
    if "sem dado" in linha.lower():
        return "in"
    return "at"


def _parse_briefing_md(caminho_md: str):
    """Recorta os 3 blocos do markdown real e devolve dict pronto pra
    renderizar_dashboard(). Bloco ausente ou vazio -> None (vira
    'Sem dado hoje' automaticamente dentro de renderizar_dashboard)."""
    texto = Path(caminho_md).read_text(encoding="utf-8")
    blocos = {}
    atual = None
    buffer = []
    for linha in texto.splitlines():
        if linha.startswith("## "):
            if atual is not None:
                blocos[atual] = buffer
            atual = linha[3:].strip()
            buffer = []
        elif atual is not None:
            buffer.append(linha)
    if atual is not None:
        blocos[atual] = buffer

    resultado = {"briefing": None, "radar": None, "fiscalizacao": None}
    for cabecalho, chave in _CABECALHOS.items():
        linhas = blocos.get(cabecalho, [])
        itens = []
        for linha in linhas:
            l = linha.strip()
            if l.startswith("- "):
                titulo, corpo = _split_headline_corpo(l)
                status = _status_da_linha(l)
                itens.append([status, titulo, corpo])
        if not itens:
            resultado[chave] = None
        else:
            resultado[chave] = itens
    return resultado


def _montar_alertas(dados: dict):
    alertas = []
    for chave, prefixo in (("radar", "Radar de Nomeações"), ("fiscalizacao", "Fiscalização")):
        itens = dados.get(chave)
        if not itens:
            alertas.append({"p": "in", "t": f"{prefixo}: sem dado hoje",
                             "o": "AFEx-g", "m": "gab"})
        else:
            for status, titulo, _ in itens[:2]:
                alertas.append({"p": status, "t": titulo, "o": prefixo, "m": "gab"})
    for status, titulo, _ in (dados.get("briefing") or [])[:3]:
        alertas.append({"p": status, "t": titulo, "o": "AIM-g", "m": "gab"})
    return alertas


def main():
    import argparse
    from datetime import date

    hoje = date.today().strftime("%Y%m%d")
    hoje_br = date.today().strftime("%d/%m/%Y")

    ap = argparse.ArgumentParser(description="Render Dashboard Real a partir do briefing do dia")
    ap.add_argument("briefing_md", nargs="?", default=f"briefing_{hoje}.md",
                     help="caminho do briefing_AAAAMMDD.md (padrão: o de hoje, "
                          "igual ao render_briefing_evora.py)")
    ap.add_argument("--template", default="dashboard_template.html")
    ap.add_argument("--saida", default=f"Dashboard_Real_{hoje}.html")
    ap.add_argument("--data", default=hoje_br, help="DD/MM/AAAA (padrão: hoje)")
    args = ap.parse_args()

    if not Path(args.briefing_md).exists():
        print(f"  (Dashboard real pulado: {args.briefing_md} ainda não existe "
              "— rode o Montador primeiro.)")
        return
    if not Path(args.template).exists():
        print(f"  (Dashboard real pulado: {args.template} não encontrado na pasta do motor.)")
        return

    dados = _parse_briefing_md(args.briefing_md)
    dados["data_referencia"] = args.data
    dados["alertas"] = _montar_alertas(dados)

    caminho = renderizar_dashboard(args.template, args.saida, dados)
    print(f"Dashboard real gerado: {caminho}")


if __name__ == "__main__":
    main()
