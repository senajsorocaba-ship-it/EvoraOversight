#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ÉVORA OVERSIGHT — Coletor PNCP (motor v2 · alimenta o AFEx-g · Fiscalização)
============================================================================
Lê contratos do Portal Nacional de Contratações Públicas (PNCP) e prepara a
lista para o AFEx-g sinalizar — por INDÍCIO, nunca acusação — itens com valor
fora da referência, para verificação HUMANA.

Mudança v2 (achado C2 da Revisão): o LIMIAR e o MUNICÍPIO vêm do PERFIL DO
TENANT (fiscalizacao.limiar_desvio_pct — decisão travada no Manual: 25%),
com fallback 25%. Nada de valor fixo no código.

PRINCÍPIO PÉTREO: o AFEx-g levanta indício e declara a base de comparação;
a decisão é sempre humana. Este coletor NÃO conclui irregularidade.

ATENÇÃO (pendência do Blueprint): confirmar endpoint/campos exatos da API de
consulta do PNCP na implementação real (a API evolui). Ajustar no go-live.

Só biblioteca padrão. Saída: contratos_sorocaba.json
"""
import json, urllib.request, urllib.parse, urllib.error, statistics
from datetime import date, timedelta

from perfil_loader_evora import carregar_perfil, limiar_desvio, autoridade

BASE    = "https://pncp.gov.br/api/consulta/v1/contratos"
DIAS    = 30
TIMEOUT = 30


def _get(url):
    req = urllib.request.Request(url, headers={"User-Agent": "Evora-Oversight/2.0"})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
        return json.loads(r.read().decode("utf-8"))


def buscar_contratos():
    fim = date.today()
    ini = fim - timedelta(days=DIAS)
    params = {
        "dataInicial": ini.strftime("%Y%m%d"),
        "dataFinal":   fim.strftime("%Y%m%d"),
        "pagina":      "1",
        # filtros adicionais (confirmar nomes na API real):
        # "codigoMunicipioIbge": ..., "cnpjOrgao": ...
    }
    url = f"{BASE}?{urllib.parse.urlencode(params)}"
    try:
        dados = _get(url)
    except urllib.error.URLError as e:
        print(f"  ! sem conexão com o PNCP ({e.reason}) — bloco seguirá 'Sem dado hoje.'")
        return []
    except Exception as e:
        print(f"  ! erro ao consultar o PNCP: {e}")
        return []
    itens = dados.get("data", dados) if isinstance(dados, dict) else dados
    return itens if isinstance(itens, list) else []


def normalizar(itens, municipio):
    out = []
    for it in itens:
        def g(*chaves):
            for k in chaves:
                if isinstance(it, dict) and it.get(k) not in (None, ""):
                    return it[k]
            return ""
        mun = str(g("municipioNome", "municipio", "nomeMunicipio"))
        if municipio and mun and municipio.lower() not in mun.lower():
            continue
        out.append({
            "numero":          g("numeroControlePNCP", "numeroContrato", "numero"),
            "objeto":          g("objetoContrato", "objeto", "descricaoObjeto"),
            "valor":           float(g("valorGlobal", "valorInicial", "valor") or 0),
            "orgao":           g("orgaoEntidadeRazaoSocial", "orgao", "nomeOrgao"),
            "fornecedor":      g("nomeRazaoSocialFornecedor", "fornecedor", "nomeFornecedor"),
            "data_publicacao": g("dataPublicacaoPncp", "dataPublicacao", "data"),
            "municipio":       mun,
        })
    return out


def sinalizar_indicios(contratos, limiar):
    """Marca indício quando o valor está acima da mediana dos comparáveis.
    Base de comparação SEMPRE declarada. Nunca afirma irregularidade."""
    valores = [c["valor"] for c in contratos if c["valor"] > 0]
    if len(valores) < 4:
        for c in contratos:
            c["relevancia"], c["indicio"] = "rotina", ""
        return contratos
    mediana = statistics.median(valores)
    for c in contratos:
        if c["valor"] > 0 and c["valor"] > mediana * (1 + limiar):
            desvio = (c["valor"] / mediana - 1) * 100
            c["relevancia"] = "atenção"
            c["indicio"] = (f"valor ~{desvio:.0f}% acima da mediana dos contratos "
                            f"do período; sugiro verificar. Base: mediana de "
                            f"{len(valores)} contratos no PNCP (R$ {mediana:,.2f}). "
                            f"Limiar do tenant: {int(limiar*100)}%.")
        else:
            c["relevancia"], c["indicio"] = "rotina", ""
    return contratos


def main():
    p = carregar_perfil()
    a = autoridade(p)
    municipio, uf = a.get("municipio", ""), a.get("uf", "")
    limiar = limiar_desvio(p)

    print("=" * 64)
    print("ÉVORA — Coletor PNCP (AFEx-g · Fiscalização do Executivo) · v2")
    print(f"Município: {municipio}/{uf} · janela: {DIAS} dias · "
          f"limiar (do perfil): {int(limiar*100)}%")
    print("=" * 64)

    brutos = buscar_contratos()
    print(f"→ {len(brutos)} contratos retornados pelo PNCP")
    contratos = sinalizar_indicios(normalizar(brutos, municipio), limiar)

    indicios = [c for c in contratos if c.get("indicio")]
    print(f"→ {len(contratos)} contratos de {municipio}; {len(indicios)} com indício para verificar\n")
    for c in indicios[:10]:
        print(f"• {c['objeto'][:60]}  | R$ {c['valor']:,.2f}")
        print(f"  INDÍCIO (verificar, não acusação): {c['indicio']}")

    with open("contratos_sorocaba.json", "w", encoding="utf-8") as f:
        json.dump(contratos, f, ensure_ascii=False, indent=2)
    print("\n✓ Salvo em contratos_sorocaba.json (insumo do AFEx-g)")
    print("  Lembrete: indício é para verificação humana — nunca acusação.")


if __name__ == "__main__":
    main()
