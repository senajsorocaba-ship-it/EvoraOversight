#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ÉVORA OVERSIGHT — Coletor de Imprensa (motor v2 · alimenta o AIM-g)
===================================================================
Busca notícias no Google News (feed RSS público, sem chave/sem custo) sobre
a autoridade, a cidade e os temas de interesse do PERFIL DO TENANT.

Mudança v2 (achado C5 da Revisão): as CONSULTAS são GERADAS DO PERFIL
(variações do nome — incluindo "Vereadora Tati", "Vereadora Tatiane",
"Gabinete 6" quando presentes no perfil —, órgãos, temas e veículos).
Trocar de cliente = trocar o perfil, sem tocar no código.

Só biblioteca padrão (urllib + xml). Saída: terminal + noticias.json
Nota: no MVP os veículos entram via Google News (agregador). O conector
direto por site (Cruzeiro do Sul, Z Norte etc.) entra na fase COM.
"""
import json, urllib.request, urllib.parse, urllib.error
import xml.etree.ElementTree as ET
from html import unescape
import re

from perfil_loader_evora import carregar_perfil, consultas_imprensa

JANELA = "7d"
MAX_POR_CONSULTA = 8
IDIOMA = "hl=pt-BR&gl=BR&ceid=BR:pt-BR"
BASE = "https://news.google.com/rss/search?q="


def _get(url):
    req = urllib.request.Request(url, headers={"User-Agent": "Evora-Oversight/2.0"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return r.read()


def _limpa(txt):
    if not txt:
        return ""
    return unescape(re.sub(r"<[^>]+>", "", txt)).strip()


def buscar(consulta):
    q = urllib.parse.quote(f"{consulta} when:{JANELA}")
    url = f"{BASE}{q}&{IDIOMA}"
    try:
        xml = _get(url)
    except urllib.error.URLError as e:
        print(f"  ! sem conexão em '{consulta}': {e.reason}")
        return []
    except Exception as e:
        print(f"  ! erro em '{consulta}': {e}")
        return []
    try:
        root = ET.fromstring(xml)
    except ET.ParseError:
        return []
    itens = []
    for item in root.iter("item"):
        titulo = _limpa(item.findtext("title"))
        link = item.findtext("link") or ""
        data = item.findtext("pubDate") or ""
        fonte_el = item.find("source")
        fonte = _limpa(fonte_el.text) if fonte_el is not None else ""
        if not fonte and " - " in titulo:
            titulo, fonte = titulo.rsplit(" - ", 1)
        itens.append({"titulo": titulo, "fonte": fonte, "data": data,
                      "link": link, "consulta": consulta})
        if len(itens) >= MAX_POR_CONSULTA:
            break
    return itens


def dedup(itens):
    visto, out = set(), []
    for it in itens:
        chave = it["titulo"].lower()[:80]
        if chave not in visto:
            visto.add(chave)
            out.append(it)
    return out


def main():
    p = carregar_perfil()
    consultas = consultas_imprensa(p)

    print("=" * 64)
    print("ÉVORA — Coletor de Imprensa (AIM-g · Monitoramento) · v2")
    print(f"Tenant: {p.get('tenant')} · janela: últimos {JANELA} · "
          f"{len(consultas)} consultas geradas do perfil")
    print("=" * 64)

    todos = []
    for c in consultas:
        print(f"→ buscando: {c}")
        todos += buscar(c)
    todos = dedup(todos)

    print(f"\n{len(todos)} notícias (após deduplicação):\n")
    print("-" * 64)
    print("BLOCO MONITORAMENTO — imprensa e menções")
    print("-" * 64)
    for n in todos[:20]:
        print(f"\n• {n['titulo']}")
        print(f"  {n['fonte']}  ·  {n['data']}")

    with open("noticias.json", "w", encoding="utf-8") as f:
        json.dump(todos, f, ensure_ascii=False, indent=2)
    print("\n✓ Salvo em noticias.json (insumo do AIM-g para o briefing)")
    print("  Obs.: o AIM-g depois filtra por relevância e escreve o bloco.")


if __name__ == "__main__":
    main()
