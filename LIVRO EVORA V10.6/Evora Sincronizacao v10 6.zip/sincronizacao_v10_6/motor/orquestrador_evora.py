#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ÉVORA OVERSIGHT — Orquestrador do Briefing (motor v2)
=====================================================
Roda o pipeline completo do Briefing Matinal, na ordem:
  1) coletor de imprensa   -> noticias.json
  2) coletor do PNCP       -> contratos_sorocaba.json
  3) montador (a Bia)      -> briefing_AAAAMMDD.md   (usa a API da Claude)
  4) render                -> briefing_AAAAMMDD.html
  5) dashboard real        -> Dashboard_Real_AAAAMMDD.html
     (só os painéis Briefing, Radar de Nomeações e Fiscalização — decisão
     do fundador em 19/07/2026; o resto do dashboard segue protótipo até
     o banco/Etapa 3 subir)

Mudanças v2 (achados C7 e C8 da Revisão):
  C8 — o orquestrador SÓ declara "Briefing gerado" após verificar que o
       arquivo HTML de hoje EXISTE (nunca maquiar resultado).
  C7 — cópia automática do HTML para a pasta "Evora Fable" na Área de
       Trabalho (decisão do fundador): acha o Desktop mesmo com OneDrive
       ou Windows em português; se não achar, AVISA e o arquivo fica na
       pasta do motor — nunca falha em silêncio.

Tolerante a falha: coletor que cai vira aviso em avisos_evora.log e o
pipeline segue com o que tem (degradar avisando, nunca falhar em silêncio).

USO:  python orquestrador_evora.py
Requer ANTHROPIC_API_KEY (só para o passo 3):
  Windows (PowerShell):  $env:ANTHROPIC_API_KEY = "sua-chave"
  Mac/Linux:             export ANTHROPIC_API_KEY="sua-chave"
"""
import subprocess, sys, os, shutil
from datetime import datetime, date

PASSOS = [
    ("Coletor de imprensa", "imprensa_coletor_evora.py", False),
    ("Coletor do PNCP",     "coletor_pncp_evora.py",     False),
    ("Montador (Bia escreve o briefing)", "montador_briefing_evora.py", True),
    ("Render do briefing",  "render_briefing_evora.py",  False),
    # 19/07/2026 — decisão do fundador: tornar reais os painéis Briefing,
    # Radar de Nomeações e Fiscalização do Dashboard (protótipo recuperado
    # do WhatsApp em 15/07). Lê o briefing_AAAAMMDD.md que o passo acima
    # gerou; nunca inventa — bloco sem dado real vira "Sem dado hoje" no
    # próprio dashboard. Não-crítico: se faltar, o briefing continua saindo.
    ("Dashboard real (Briefing+Radar+Fiscalização)", "render_dashboard_evora.py", False),
]


def aviso(msg):
    linha = f"{datetime.now():%Y-%m-%d %H:%M:%S} · {msg}\n"
    with open("avisos_evora.log", "a", encoding="utf-8") as f:
        f.write(linha)
    print("  ⚠  " + msg)


def roda(nome, script, critico):
    print(f"\n▶ {nome}  ({script})")
    if not os.path.exists(script):
        aviso(f"{nome}: script {script} não encontrado — passo pulado.")
        return not critico
    try:
        r = subprocess.run([sys.executable, script], timeout=300)
        if r.returncode != 0:
            aviso(f"{nome}: terminou com código {r.returncode}.")
            return not critico
        return True
    except subprocess.TimeoutExpired:
        aviso(f"{nome}: tempo esgotado (timeout).")
        return not critico
    except Exception as e:
        aviso(f"{nome}: erro {e}.")
        return not critico


def achar_desktop():
    """Localiza a Área de Trabalho no Windows (com OneDrive/pt-BR) ou Unix.
    Devolve None se não encontrar — quem chama avisa (nunca em silêncio)."""
    home = os.path.expanduser("~")
    candidatos = []
    onedrive = os.environ.get("OneDrive") or os.environ.get("ONEDRIVE")
    if onedrive:
        candidatos += [os.path.join(onedrive, "Desktop"),
                       os.path.join(onedrive, "Área de Trabalho")]
    candidatos += [os.path.join(home, "Desktop"),
                   os.path.join(home, "Área de Trabalho")]
    for c in candidatos:
        if os.path.isdir(c):
            return c
    return None


def copiar_para_desktop(arquivo):
    desktop = achar_desktop()
    if not desktop:
        aviso("Área de Trabalho não localizada — a cópia ficou só na pasta do motor.")
        return None
    destino_dir = os.path.join(desktop, "Evora Fable")
    try:
        os.makedirs(destino_dir, exist_ok=True)
        destino = os.path.join(destino_dir, os.path.basename(arquivo))
        shutil.copy2(arquivo, destino)
        return destino
    except OSError as e:
        aviso(f"Falha ao copiar para a Área de Trabalho ({e}) — arquivo segue na pasta do motor.")
        return None


def main():
    print("=" * 64)
    print("ÉVORA OVERSIGHT — Orquestrador do Briefing Matinal · motor v2")
    print(f"Data: {date.today():%d/%m/%Y}")
    print("=" * 64)
    if not os.environ.get("ANTHROPIC_API_KEY"):
        aviso("ANTHROPIC_API_KEY não definida — o passo do montador vai falhar. "
              'Windows: $env:ANTHROPIC_API_KEY = "..."  ·  Mac/Linux: export ANTHROPIC_API_KEY="..."')
    for nome, script, critico in PASSOS:
        if not roda(nome, script, critico):
            print(f"\n✗ Pipeline interrompido em: {nome} (passo crítico).")
            print("  Veja avisos_evora.log para o histórico rastreado.")
            return

    # C8 — só declarar sucesso se o resultado EXISTIR (verdade acima da conveniência)
    nome_html = f"briefing_{date.today():%Y%m%d}.html"
    print("\n" + "=" * 64)
    if os.path.exists(nome_html):
        print("✓ Briefing gerado.")
        print(f"  Abra: {nome_html}")
        destino = copiar_para_desktop(nome_html)
        if destino:
            print(f"  Cópia na Área de Trabalho: {destino}")
        nome_dash = f"Dashboard_Real_{date.today():%Y%m%d}.html"
        if os.path.exists(nome_dash):
            print(f"  Dashboard real: {nome_dash}")
    else:
        aviso(f"O pipeline terminou, mas {nome_html} NÃO foi encontrado — "
              "verifique o passo do render em avisos_evora.log.")
        print("✗ Briefing NÃO gerado (arquivo ausente). Nada foi maquiado.")
    print("  Avisos (se houver): avisos_evora.log")
    print("=" * 64)


if __name__ == "__main__":
    main()
