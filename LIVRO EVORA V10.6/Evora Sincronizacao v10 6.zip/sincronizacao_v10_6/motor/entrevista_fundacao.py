"""
Évora Oversight — Entrevista de Fundação
=========================================
Conduz as 14 perguntas do onboarding do tenant e emite o
`perfil_<tenant>.json` que o motor de briefing já lê hoje.

Base normativa: Manual Supremo v10.6, Anexo 16 §5.
Decisão D7 (fundador, 19/07/2026): construir a Entrevista ANTES do Atlas —
é o que destrava a venda do 2º tenant.

TRAVAS DESTE COMPONENTE (não são opcionais)
-------------------------------------------
1. Tudo que o tenant declara entra como `declarado`, NUNCA como `verificado`.
   Declaração é hipótese de trabalho; fato é fato. O sistema não corrige o
   tenant nem apaga o que ele disse — guarda os dois.
2. A ciência das 3 travas (bloco final) é OBRIGATÓRIA. Sem ela o perfil é
   gravado com `operacional: false` e o go-live não acontece (decisão D5).
3. Influencers e perfis pessoais entram como nível F3, dentro do perfil
   isolado do tenant, com finalidade declarada — NUNCA no Atlas (Anexo 16 §3).
4. O script não inventa: campo não respondido fica vazio e visível, não
   preenchido por suposição.

USO
---
    python entrevista_fundacao.py                 # interativo
    python entrevista_fundacao.py --saida perfil_fulano.json
    python entrevista_fundacao.py --respostas respostas.json   # não-interativo

O modo --respostas existe para (a) testar sem digitar, (b) permitir que uma
tela web colete as respostas e chame este mesmo motor, sem duplicar regra.
"""

import json
import re
import sys
import unicodedata
from collections import OrderedDict
from datetime import date
from pathlib import Path

VERSAO = "v10.6 · Anexo 16 §5"

# ---------------------------------------------------------------------------
# As 14 perguntas, em 4 blocos (Manual v10.6, Anexo 16 §5)
# ---------------------------------------------------------------------------
PERGUNTAS = [
    # bloco 1 — identidade e alcance
    ("p1",  1, "Nome completo, como aparece nos atos oficiais", "texto"),
    ("p2",  1, "Como te chamam na cidade? Todos os apelidos e variações usados na imprensa "
                "(separe por vírgula)", "lista"),
    ("p3a", 1, "Cargo atual", "texto"),
    ("p3b", 1, "Partido", "texto"),
    ("p3c", 1, "Município (cidade-sede do mandato)", "texto"),
    ("p3d", 1, "UF", "texto"),
    ("p4",  1, "É primeiro mandato? Se não, quantos e desde quando?", "texto"),
    # bloco 2 — bandeiras e território
    ("p5",  2, "Até 5 temas que definem seu mandato (separe por vírgula)", "lista"),
    ("p6",  2, "Bairros ou regiões da cidade que são sua base (separe por vírgula)", "lista"),
    ("p7",  2, "Órgãos que você mais fiscaliza ou acompanha (separe por vírgula)", "lista"),
    ("p8",  2, "Pessoas públicas cujas ações você precisa acompanhar (separe por vírgula; "
                "só figuras públicas)", "lista"),
    ("p8f", 2, "  ↳ Finalidade desse acompanhamento (obrigatória se respondeu acima)", "texto"),
    # bloco 3 — como quer ser servido
    ("p9",  3, "A que horas quer o briefing? (padrão 06:45)", "texto"),
    ("p10", 3, "Prefere texto curto e direto, ou explicado com contexto? "
                "(responda: direto / contexto)", "texto"),
    ("p11", 3, "Quem mais no gabinete recebe o briefing, e com que papel? "
                "(ex.: Maria — chefe de gabinete)", "lista"),
    ("p12", 3, "Quer o briefing por tela, voz, ou os dois? (tela / voz / ambos)", "texto"),
    # bloco 4 — fiscalização e limites
    ("p13", 4, "A partir de quantos % acima do preço de referência você quer ser avisado? "
                "(padrão 25)", "numero"),
    ("p14", 4, "Há assunto que você NÃO quer no briefing? (separe por vírgula; enter para nenhum)",
                "lista"),
]

BLOCOS = {
    1: "BLOCO 1 — Identidade e alcance",
    2: "BLOCO 2 — Bandeiras e território",
    3: "BLOCO 3 — Como você quer ser servido",
    4: "BLOCO 4 — Fiscalização e limites",
}

TRAVAS_CIENCIA = [
    "Indício nunca é acusação. O sistema sinaliza o que merece verificação; "
    "quem acusa é pessoa, com assessoria jurídica.",
    "Nada é publicado ou executado sem aprovação humana. O sistema propõe; "
    "a decisão é sempre sua.",
    "O sistema recusa o ilícito — inclusive vindo de você, do seu gabinete ou "
    "do criador da plataforma.",
]


# ---------------------------------------------------------------------------
# utilitários
# ---------------------------------------------------------------------------
def _slug(texto):
    """'Tatiane Costa' + 'Sorocaba' -> 'tatiane-costa-sorocaba'"""
    t = unicodedata.normalize("NFKD", texto).encode("ascii", "ignore").decode()
    t = re.sub(r"[^a-zA-Z0-9]+", "-", t).strip("-").lower()
    return re.sub(r"-{2,}", "-", t)


def _lista(txt):
    return [x.strip() for x in (txt or "").split(",") if x.strip()]


def _variacoes(nome, apelidos, cargo):
    """Monta as variações do nome para o coletor de imprensa, sem inventar:
    parte do que o tenant declarou e acrescenta as formas de tratamento
    do próprio cargo que ele informou."""
    out = [nome] + apelidos
    if cargo and nome:
        primeiro = nome.split()[0]
        out += [f"{cargo} {nome}", f"{cargo} {primeiro}"]
    visto, final = set(), []
    for v in out:
        v = (v or "").strip()
        if v and v.lower() not in visto:
            visto.add(v.lower())
            final.append(v)
    return final


# ---------------------------------------------------------------------------
# coleta
# ---------------------------------------------------------------------------
def perguntar_interativo():
    print("=" * 68)
    print("  ÉVORA OVERSIGHT — ENTREVISTA DE FUNDAÇÃO")
    print(f"  14 perguntas · cerca de 8 minutos · {VERSAO}")
    print("=" * 68)
    print("\n  Suas respostas montam o perfil inicial do seu mandato.")
    print("  Nada aqui é definitivo: o sistema aprende com o uso e ajusta.")
    print("  Pode deixar em branco o que não souber agora — vazio é melhor")
    print("  que chute, e o sistema mostra o que está faltando.\n")

    respostas = OrderedDict()
    bloco_atual = None
    for chave, bloco, texto, _tipo in PERGUNTAS:
        if bloco != bloco_atual:
            bloco_atual = bloco
            print(f"\n--- {BLOCOS[bloco]} ---\n")
        try:
            respostas[chave] = input(f"{texto}\n> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n\nEntrevista interrompida. Nada foi gravado.")
            sys.exit(1)
        print()
    respostas["_ciencia"] = _colher_ciencia()
    return respostas


def _colher_ciencia():
    """Bloco final obrigatório (decisão D5). Sem ciência registrada,
    o tenant não entra em operação."""
    print("\n" + "=" * 68)
    print("  ANTES DE COMEÇAR — três travas do sistema")
    print("=" * 68 + "\n")
    for i, t in enumerate(TRAVAS_CIENCIA, 1):
        print(f"  {i}. {t}\n")
    try:
        r = input("Você leu e está ciente das três travas acima? (sim/não)\n> ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        return False
    return r.startswith("s")


# ---------------------------------------------------------------------------
# montagem do perfil
# ---------------------------------------------------------------------------
def montar_perfil(r):
    nome = r.get("p1", "").strip()
    cargo = r.get("p3a", "").strip()
    municipio = r.get("p3c", "").strip()
    uf = r.get("p3d", "").strip().upper()
    ciente = bool(r.get("_ciencia"))

    try:
        limiar = int(float(str(r.get("p13", "")).replace("%", "").replace(",", ".").strip() or 25))
    except ValueError:
        limiar = 25

    horario = r.get("p9", "").strip() or "06:45"
    modo = "direto" if r.get("p10", "").strip().lower().startswith("d") else "contexto"
    tom = ("factual, conciso, direto; sem opinião pessoal nem recomendação de voto"
           if modo == "direto" else
           "factual e explicado, com contexto suficiente para decidir; sem opinião "
           "pessoal nem recomendação de voto")

    pessoas = _lista(r.get("p8", ""))
    finalidade = r.get("p8f", "").strip()

    p = OrderedDict()
    p["tenant"] = _slug(f"{nome} {municipio}") or "tenant-sem-nome"
    p["autoridade"] = OrderedDict([
        ("nome", nome),
        ("variacoes_nome", _variacoes(nome, _lista(r.get("p2", "")), cargo)),
        ("cargo_atual", cargo),
        ("partido", r.get("p3b", "").strip()),
        ("municipio", municipio),
        ("municipio_sede", municipio),
        ("uf", uf),
        ("area_atuacao", [{"municipio": municipio, "uf": uf, "papel": "sede do mandato"}] if municipio else []),
        ("mandatos", r.get("p4", "").strip()),
    ])
    p["briefing"] = OrderedDict([
        ("horario", horario),
        ("fuso", "America/Sao_Paulo"),
        ("tom", tom),
        ("profundidade", modo),
        ("canal", (r.get("p12", "").strip().lower() or "tela")),
        ("blocos", [
            "Resumo do dia",
            "Radar de Nomeações (AFEx-g)",
            f"Fiscalização do Executivo (limiar {limiar}%)",
            "Pulso da Câmara / Diário Oficial",
            "Demandas & Requerimentos",
            "Monitoramento & Imprensa",
            "Movimento sugerido (72h)",
        ]),
        ("carater", "Cláusula de Caráter Travado: sem invenção; fonte declarada em tudo (CVI); "
                    "'não sei' é válido; nada não-ordenado; freio humano (nada é executado sem "
                    "aprovação)."),
        ("exclusoes", _lista(r.get("p14", ""))),
        ("destinatarios", _lista(r.get("p11", ""))),
    ])
    p["monitoramento"] = OrderedDict([
        ("temas", _lista(r.get("p5", ""))[:5]),
        ("territorio", _lista(r.get("p6", ""))),
        ("orgaos", _lista(r.get("p7", ""))),
        ("politicos_pessoas", pessoas),
        ("politicos_pessoas_finalidade", finalidade),
        ("veiculos", []),
        ("veiculos_detalhe", []),
        ("influencers_f3", []),
        ("_nota_veiculos", "Vazio de propósito: o Atlas Municipal preenche os veículos F1/F2 da "
                            "cidade na implantação (Anexo 16 §2). Verificação humana da mídia local "
                            "é obrigatória antes do go-live (decisão D6)."),
        ("_nota_f3", "Influencers e perfis pessoais entram aqui (F3), com finalidade declarada e "
                      "visíveis na auditoria. Nunca sobem ao Atlas compartilhado."),
    ])
    p["fiscalizacao"] = OrderedDict([
        ("ambito", "municipal"),
        ("limiar_desvio_pct", limiar),
        ("regra", "indício para verificação humana; nunca acusação; base de comparação sempre declarada"),
        ("radar_nomeacoes", "Diário Oficial: nomeações e exonerações (nome, cargo, secretaria) + "
                            "cruzamento com pessoas de interesse. Indício, nunca acusação."),
        ("fontes", ["Diário Oficial do município (via COM — conector a definir na implantação)", "PNCP"]),
    ])
    p["travas"] = OrderedDict([
        ("freio_humano", True),
        ("fontes_publicas_e_licitas", True),
        ("lgpd_termo_demandas", "obrigatório desde o dia 1"),
        ("separacao_gabinete_campanha", True),
        ("ciencia_registrada", ciente),
        ("ciencia_data", date.today().isoformat() if ciente else ""),
        ("ciencia_texto", TRAVAS_CIENCIA),
    ])
    p["operacional"] = ciente
    if not ciente:
        p["_bloqueio"] = ("Go-live bloqueado: a ciência das 3 travas não foi registrada "
                          "(Manual v10.6, Anexo 16 §5 — decisão D5). Rode a entrevista novamente "
                          "e confirme a ciência para liberar a operação.")

    p["_procedencia"] = OrderedDict([
        ("autoridade", "declarado"),
        ("monitoramento.temas", "declarado"),
        ("monitoramento.politicos_pessoas", f"declarado — finalidade: {finalidade or '[NÃO INFORMADA]'}"),
        ("monitoramento.veiculos", "pendente — será preenchido pelo Atlas (atlas) + verificação humana"),
        ("fiscalizacao.limiar_desvio_pct", "declarado"),
        ("_regra", "declarado = veio da Entrevista de Fundação · atlas = veio do Atlas Municipal · "
                    "verificado = confirmado em fonte pública, com data e link"),
    ])
    p["_versao_perfil"] = (f"{VERSAO} · gerado pela Entrevista de Fundação em "
                            f"{date.today().strftime('%d/%m/%Y')} · respostas do tenant entram como "
                            f"'declarado', nunca como 'verificado'")
    return p


def avisos(p):
    """O que o operador precisa saber antes do go-live — dito na cara,
    não escondido no JSON."""
    av = []
    if not p.get("operacional"):
        av.append("BLOQUEIO: ciência das 3 travas não registrada — go-live impedido (D5).")
    if not p["autoridade"]["nome"]:
        av.append("Nome da autoridade vazio — o coletor de imprensa não terá o que buscar.")
    if not p["autoridade"]["municipio"]:
        av.append("Município vazio — sem ele o Atlas não consegue ligar as fontes da cidade.")
    if not p["monitoramento"]["temas"]:
        av.append("Nenhum tema informado — o briefing sairá genérico até que se preencha.")
    if p["monitoramento"]["politicos_pessoas"] and not p["monitoramento"]["politicos_pessoas_finalidade"]:
        av.append("Pessoas a acompanhar informadas SEM finalidade declarada — exigida pelo Anexo 16 §5.")
    av.append("Veículos vazios: rode o Atlas Municipal e faça a verificação humana da mídia "
              "local antes do go-live (D6).")
    return av


def main():
    import argparse
    ap = argparse.ArgumentParser(description="Entrevista de Fundação — Évora Oversight")
    ap.add_argument("--saida", default=None, help="arquivo de saída (padrão: perfil_<tenant>.json)")
    ap.add_argument("--respostas", default=None,
                    help="JSON com as respostas (modo não-interativo, para testes ou tela web)")
    args = ap.parse_args()

    if args.respostas:
        r = json.loads(Path(args.respostas).read_text(encoding="utf-8"))
    else:
        r = perguntar_interativo()

    p = montar_perfil(r)
    saida = args.saida or f"perfil_{p['tenant']}.json"
    Path(saida).write_text(json.dumps(p, ensure_ascii=False, indent=1), encoding="utf-8")

    print("\n" + "=" * 68)
    print(f"  Perfil gerado: {saida}")
    print(f"  Tenant: {p['tenant']}")
    print(f"  Operacional: {'SIM' if p['operacional'] else 'NÃO (ver bloqueio abaixo)'}")
    print("=" * 68)
    print("\n  O que ainda falta antes do go-live:\n")
    for a in avisos(p):
        print(f"   · {a}")
    print("\n  Próximo passo: rodar o orquestrador para o briefing de teste")
    print("  (passo 5 da implantação — Manual v10.6, Anexo 13).\n")


if __name__ == "__main__":
    main()
