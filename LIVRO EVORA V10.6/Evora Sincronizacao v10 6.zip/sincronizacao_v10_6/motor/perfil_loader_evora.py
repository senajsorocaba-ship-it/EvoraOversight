#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ÉVORA OVERSIGHT — Carregador do Perfil do Tenant (motor v2)
===========================================================
Fonte única do multi-tenant: identidade, tom, blocos, limiar e consultas
vêm do perfil. Trocar de cliente = trocar o perfil, sem tocar no código.

Uso pelos demais scripts:
    from perfil_loader_evora import carregar_perfil
    p = carregar_perfil()            # perfil_tatiane.json por padrão
    p = carregar_perfil("outro.json")
Aceita também variável de ambiente EVORA_PERFIL apontando o arquivo.
Só biblioteca padrão.
"""
import json, os, sys

PADRAO = "perfil_tatiane.json"

BLOCOS_FALLBACK = [
    "Resumo do dia",
    "Radar de Nomeações (AFEx-g)",
    "Fiscalização do Executivo (limiar 25%)",
    "Pulso da Câmara / Diário Oficial",
    "Demandas & Requerimentos",
    "Monitoramento & Imprensa",
    "Movimento sugerido (72h)",
]


def carregar_perfil(caminho=None):
    """Carrega o perfil do tenant. Falha com mensagem clara (nunca em silêncio)."""
    caminho = caminho or os.environ.get("EVORA_PERFIL") or PADRAO
    if not os.path.exists(caminho):
        raise SystemExit(
            f"⚠️  Perfil do tenant não encontrado: {caminho}\n"
            "   O motor v2 é dirigido pelo perfil (multi-tenant). "
            "Coloque o arquivo na pasta ou aponte EVORA_PERFIL."
        )
    try:
        with open(caminho, encoding="utf-8") as f:
            p = json.load(f)
    except json.JSONDecodeError as e:
        raise SystemExit(f"⚠️  Perfil inválido ({caminho}): JSON malformado — {e}")
    p["_arquivo"] = caminho
    return p


def limiar_desvio(p):
    """Limiar de fiscalização como fração (0.25 = 25%).
    Fonte única: fiscalizacao.limiar_desvio_pct (decisão travada: 25%).
    Fallback: 25%. Aceita o campo legado limiar_desvio se for o único presente."""
    fisc = p.get("fiscalizacao", {}) or {}
    pct = fisc.get("limiar_desvio_pct")
    if isinstance(pct, (int, float)) and pct > 0:
        return float(pct) / 100.0
    legado = fisc.get("limiar_desvio")
    if isinstance(legado, (int, float)) and 0 < legado < 1:
        return float(legado)
    return 0.25


def blocos(p):
    b = (p.get("briefing", {}) or {}).get("blocos") or []
    return b if b else list(BLOCOS_FALLBACK)


def autoridade(p):
    return p.get("autoridade", {}) or {}


def _veiculos_normalizados(mon):
    """[v10.6] Devolve os nomes dos veículos que entram na varredura de
    imprensa, aceitando os dois formatos do perfil:
      - legado:  "veiculos": ["Cruzeiro do Sul (url)", ...]
      - v10.6:   "veiculos_detalhe": [{"nome":..., "nivel":"F1"}, ...]
    Regra travada (Anexo 16 §3): F3 (influencers e perfis pessoais) fica de
    fora — tem finalidade declarada própria e nunca se mistura à varredura
    geral. Se o perfil trouxer os dois formatos, o detalhado tem precedência.
    """
    detalhe = mon.get("veiculos_detalhe") or []
    if detalhe:
        nomes = []
        for v in detalhe:
            if isinstance(v, dict):
                if str(v.get("nivel", "")).upper() == "F3":
                    continue
                nome = v.get("nome", "")
            else:
                nome = str(v)
            if nome:
                nomes.append(nome)
        if nomes:
            return nomes
    return [v if isinstance(v, str) else v.get("nome", "")
            for v in (mon.get("veiculos") or [])]


def area_atuacao(p):
    """[v10.6] Municípios cobertos por este tenant (Anexo 16 §5).
    Mandato municipal devolve só a cidade-sede; mandato estadual/federal
    devolve a lista inteira. Sempre devolve ao menos um município."""
    a = autoridade(p)
    area = a.get("area_atuacao") or []
    nomes = [m.get("municipio") if isinstance(m, dict) else str(m) for m in area]
    nomes = [n for n in nomes if n]
    if nomes:
        return nomes
    sede = a.get("municipio_sede") or a.get("municipio") or ""
    return [sede] if sede else []


def consultas_imprensa(p):
    """Gera as consultas do coletor de imprensa a partir do perfil:
    variações do nome + órgãos + temas + veículos. Sem inventar nada
    fora do perfil; se o perfil estiver vazio, devolve lista mínima."""
    a = autoridade(p)
    mon = p.get("monitoramento", {}) or {}
    cidade = a.get("municipio", "")
    out = []

    variacoes = [v for v in a.get("variacoes_nome", []) if v]
    if variacoes:
        ors = " OR ".join(f'"{v}"' for v in variacoes[:6])
        out.append(f"{ors} {cidade}".strip())

    for orgao in mon.get("orgaos", []):
        out.append(f'"{orgao}"')

    temas = [t for t in mon.get("temas", []) if t]
    for i in range(0, len(temas), 3):
        grupo = " OR ".join(temas[i:i + 3])
        out.append(f"{cidade} {grupo}".strip())

    # [v10.6] Veículos podem vir como string (formato legado) ou como dict
    # com nível F1/F2/F3 (Manual v10.6, Anexo 16 §3). Os dois formatos
    # funcionam — o loader normaliza. Veículos F3 (influencers/perfis
    # pessoais) NÃO entram aqui: eles têm finalidade declarada própria e
    # não se misturam à varredura geral de imprensa.
    for veic in _veiculos_normalizados(mon):
        nome = veic.split("(")[0].split("—")[0].strip()
        if nome:
            out.append(f'"{nome}" {cidade}'.strip())

    # dedup preservando ordem
    visto, final = set(), []
    for c in out:
        if c and c not in visto:
            visto.add(c)
            final.append(c)
    return final or [f"{cidade} câmara prefeitura".strip() or "Sorocaba"]


if __name__ == "__main__":
    p = carregar_perfil(sys.argv[1] if len(sys.argv) > 1 else None)
    print(f"Perfil: {p.get('tenant')}  ({p['_arquivo']})")
    print(f"Autoridade: {autoridade(p).get('nome')}")
    print(f"Limiar de fiscalização: {int(limiar_desvio(p)*100)}%")
    print(f"Blocos ({len(blocos(p))}):")
    for b in blocos(p):
        print(f"  · {b}")
    print("Consultas de imprensa geradas do perfil:")
    for c in consultas_imprensa(p):
        print(f"  → {c}")
